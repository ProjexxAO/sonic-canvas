import React, { useState } from 'react';
import { Target, TrendingUp, Calendar, ChevronRight, Plus, Sparkles } from 'lucide-react';

interface Goal {
  id: string;
  title: string;
  category: string;
  progress: number;
  target: number;
  unit: string;
  deadline: string;
  color: string;
}

const GoalProgress: React.FC = () => {
  const [goals, setGoals] = useState<Goal[]>([
    { id: '1', title: 'Save for vacation', category: 'Finance', progress: 3200, target: 5000, unit: '$', deadline: 'Mar 2026', color: 'from-cyan-400 to-blue-500' },
    { id: '2', title: 'Read 24 books', category: 'Personal', progress: 18, target: 24, unit: 'books', deadline: 'Dec 2026', color: 'from-purple-400 to-pink-500' },
    { id: '3', title: 'Run 500 miles', category: 'Fitness', progress: 342, target: 500, unit: 'miles', deadline: 'Dec 2026', color: 'from-green-400 to-emerald-500' },
  ]);

  const [showAddGoal, setShowAddGoal] = useState(false);

  const updateProgress = (goalId: string, increment: number) => {
    setGoals(goals.map(goal => {
      if (goal.id === goalId) {
        const newProgress = Math.min(goal.progress + increment, goal.target);
        return { ...goal, progress: newProgress };
      }
      return goal;
    }));
  };

  return (
    <div className="bg-card rounded-2xl border border-border p-5 card-hover">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-foreground">Goal Progress</h3>
          <p className="text-xs text-muted-foreground">{goals.length} active goals</p>
        </div>
        <button
          onClick={() => setShowAddGoal(!showAddGoal)}
          className="w-8 h-8 rounded-lg bg-primary/10 hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-colors"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Goals List */}
      <div className="space-y-4">
        {goals.map((goal) => {
          const percentage = Math.round((goal.progress / goal.target) * 100);
          const isComplete = percentage >= 100;
          
          return (
            <div key={goal.id} className="group">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${goal.color} flex items-center justify-center`}>
                    {isComplete ? (
                      <Sparkles className="w-4 h-4 text-white" />
                    ) : (
                      <Target className="w-4 h-4 text-white" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-foreground">{goal.title}</h4>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs text-muted-foreground">{goal.category}</span>
                      <span className="text-xs text-muted-foreground">•</span>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">{goal.deadline}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => updateProgress(goal.id, goal.unit === '$' ? 100 : 1)}
                  className="opacity-0 group-hover:opacity-100 px-2 py-1 rounded-lg bg-primary/10 hover:bg-primary hover:text-primary-foreground text-xs font-medium transition-all"
                >
                  +{goal.unit === '$' ? '$100' : '1'}
                </button>
              </div>

              {/* Progress Bar */}
              <div className="relative">
                <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className={`h-full bg-gradient-to-r ${goal.color} rounded-full transition-all duration-500`}
                    style={{ width: `${Math.min(percentage, 100)}%` }}
                  />
                </div>
                <div className="flex items-center justify-between mt-1.5">
                  <span className="text-xs text-muted-foreground">
                    {goal.unit === '$' ? `$${goal.progress.toLocaleString()}` : goal.progress} / {goal.unit === '$' ? `$${goal.target.toLocaleString()}` : goal.target} {goal.unit !== '$' ? goal.unit : ''}
                  </span>
                  <span className={`text-xs font-semibold ${isComplete ? 'text-green-500' : 'text-foreground'}`}>
                    {percentage}%
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* View All */}
      <button className="w-full mt-4 flex items-center justify-center gap-1 py-2 text-sm text-primary hover:text-primary/80 transition-colors">
        View all goals
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
};

export default GoalProgress;
