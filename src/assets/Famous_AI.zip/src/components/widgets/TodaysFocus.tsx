import React, { useState } from 'react';
import { CheckCircle2, Circle, Clock, Flag, Plus, GripVertical } from 'lucide-react';

interface Task {
  id: string;
  title: string;
  completed: boolean;
  priority: 'high' | 'medium' | 'low';
  dueTime?: string;
}

const TodaysFocus: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([
    { id: '1', title: 'Review Q4 budget proposal', completed: false, priority: 'high', dueTime: '3:00 PM' },
    { id: '2', title: 'Team standup meeting', completed: true, priority: 'medium', dueTime: '10:00 AM' },
    { id: '3', title: 'Finalize marketing deck', completed: false, priority: 'high', dueTime: '5:00 PM' },
    { id: '4', title: 'Call with investors', completed: false, priority: 'medium', dueTime: '2:00 PM' },
    { id: '5', title: 'Review code PRs', completed: false, priority: 'low' },
  ]);
  const [newTask, setNewTask] = useState('');
  const [showInput, setShowInput] = useState(false);

  const toggleTask = (id: string) => {
    setTasks(tasks.map(task =>
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    setTasks([...tasks, {
      id: Date.now().toString(),
      title: newTask,
      completed: false,
      priority: 'medium',
    }]);
    setNewTask('');
    setShowInput(false);
  };

  const priorityColors = {
    high: 'text-red-500',
    medium: 'text-amber-500',
    low: 'text-blue-500',
  };

  const completedCount = tasks.filter(t => t.completed).length;

  return (
    <div className="bg-card rounded-2xl border border-border p-5 card-hover">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-foreground">Today's Focus</h3>
          <p className="text-xs text-muted-foreground">{completedCount}/{tasks.length} completed</p>
        </div>
        <button
          onClick={() => setShowInput(!showInput)}
          className="w-8 h-8 rounded-lg bg-primary/10 hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-colors"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Progress Bar */}
      <div className="h-1.5 bg-muted rounded-full mb-4 overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full transition-all duration-500"
          style={{ width: `${(completedCount / tasks.length) * 100}%` }}
        />
      </div>

      {/* Add Task Input */}
      {showInput && (
        <form onSubmit={addTask} className="mb-3">
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            placeholder="Add a new task..."
            autoFocus
            className="w-full bg-muted rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </form>
      )}

      {/* Task List */}
      <ul className="space-y-2">
        {tasks.map((task) => (
          <li
            key={task.id}
            className={`group flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors ${
              task.completed ? 'opacity-60' : ''
            }`}
          >
            <GripVertical className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 cursor-grab" />
            <button
              onClick={() => toggleTask(task.id)}
              className="flex-shrink-0"
            >
              {task.completed ? (
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              ) : (
                <Circle className="w-5 h-5 text-muted-foreground hover:text-primary" />
              )}
            </button>
            <div className="flex-1 min-w-0">
              <p className={`text-sm ${task.completed ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                {task.title}
              </p>
              {task.dueTime && (
                <div className="flex items-center gap-1 mt-0.5">
                  <Clock className="w-3 h-3 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">{task.dueTime}</span>
                </div>
              )}
            </div>
            <Flag className={`w-4 h-4 ${priorityColors[task.priority]}`} />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TodaysFocus;
