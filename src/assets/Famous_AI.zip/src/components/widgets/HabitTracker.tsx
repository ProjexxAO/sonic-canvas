import React, { useState } from 'react';
import { Flame, Droplets, Dumbbell, Book, Moon, Apple, Brain } from 'lucide-react';

interface Habit {
  id: string;
  name: string;
  icon: React.ElementType;
  color: string;
  streak: number;
  weekData: boolean[];
}

const HabitTracker: React.FC = () => {
  const [habits, setHabits] = useState<Habit[]>([
    { id: '1', name: 'Meditation', icon: Brain, color: 'bg-purple-500', streak: 12, weekData: [true, true, true, false, true, true, false] },
    { id: '2', name: 'Exercise', icon: Dumbbell, color: 'bg-orange-500', streak: 8, weekData: [true, false, true, true, true, false, false] },
    { id: '3', name: 'Hydration', icon: Droplets, color: 'bg-cyan-500', streak: 21, weekData: [true, true, true, true, true, true, true] },
    { id: '4', name: 'Reading', icon: Book, color: 'bg-amber-500', streak: 5, weekData: [false, true, true, true, true, true, false] },
    { id: '5', name: 'Sleep 8hrs', icon: Moon, color: 'bg-indigo-500', streak: 3, weekData: [true, false, false, true, true, true, false] },
  ]);

  const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  const today = new Date().getDay();
  const todayIndex = today === 0 ? 6 : today - 1;

  const toggleHabitDay = (habitId: string, dayIndex: number) => {
    setHabits(habits.map(habit => {
      if (habit.id === habitId) {
        const newWeekData = [...habit.weekData];
        newWeekData[dayIndex] = !newWeekData[dayIndex];
        return { ...habit, weekData: newWeekData };
      }
      return habit;
    }));
  };

  const totalStreak = habits.reduce((acc, h) => acc + h.streak, 0);

  return (
    <div className="bg-card rounded-2xl border border-border p-5 card-hover">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-foreground">Habit Tracker</h3>
          <p className="text-xs text-muted-foreground">7-day streak view</p>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-orange-500/10">
          <Flame className="w-4 h-4 text-orange-500" />
          <span className="text-sm font-semibold text-orange-500">{totalStreak}</span>
        </div>
      </div>

      {/* Day Headers */}
      <div className="flex items-center gap-2 mb-3 pl-28">
        {days.map((day, i) => (
          <div
            key={i}
            className={`w-7 h-7 flex items-center justify-center text-xs font-medium rounded-full ${
              i === todayIndex ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'
            }`}
          >
            {day}
          </div>
        ))}
      </div>

      {/* Habits */}
      <div className="space-y-2">
        {habits.map((habit) => {
          const Icon = habit.icon;
          return (
            <div key={habit.id} className="flex items-center gap-2">
              <div className="flex items-center gap-2 w-28">
                <div className={`w-7 h-7 rounded-lg ${habit.color} flex items-center justify-center`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <span className="text-sm text-foreground truncate">{habit.name}</span>
              </div>
              <div className="flex items-center gap-2">
                {habit.weekData.map((completed, i) => (
                  <button
                    key={i}
                    onClick={() => toggleHabitDay(habit.id, i)}
                    className={`w-7 h-7 rounded-lg transition-all ${
                      completed
                        ? `${habit.color} shadow-lg`
                        : 'bg-muted hover:bg-muted/80'
                    }`}
                  >
                    {completed && (
                      <svg className="w-4 h-4 mx-auto text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-1 ml-2">
                <Flame className="w-3 h-3 text-orange-500" />
                <span className="text-xs font-medium text-muted-foreground">{habit.streak}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default HabitTracker;
