import React, { useState } from 'react';
import { TrendingUp, TrendingDown, CreditCard, ArrowUpRight, ArrowDownRight, Eye, EyeOff, PiggyBank } from 'lucide-react';

interface Transaction {
  id: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  date: string;
}

const FinancialSnapshot: React.FC = () => {
  const [showBalance, setShowBalance] = useState(true);
  const balance = 24580.42;
  const monthlyChange = 12.4;
  const savingsGoal = 30000;

  const transactions: Transaction[] = [
    { id: '1', description: 'Salary Deposit', amount: 8500, type: 'income', category: 'Income', date: 'Today' },
    { id: '2', description: 'Amazon Purchase', amount: 156.99, type: 'expense', category: 'Shopping', date: 'Today' },
    { id: '3', description: 'Netflix Subscription', amount: 15.99, type: 'expense', category: 'Entertainment', date: 'Yesterday' },
  ];

  return (
    <div className="bg-card rounded-2xl border border-border p-5 card-hover">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-foreground">Financial Snapshot</h3>
          <p className="text-xs text-muted-foreground">Current balance</p>
        </div>
        <button
          onClick={() => setShowBalance(!showBalance)}
          className="w-8 h-8 rounded-lg bg-muted hover:bg-primary/10 flex items-center justify-center transition-colors"
        >
          {showBalance ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
        </button>
      </div>

      {/* Balance */}
      <div className="mb-4">
        <div className="flex items-baseline gap-2">
          <span className="metric-value text-foreground">
            {showBalance ? `$${balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '••••••'}
          </span>
          <div className={`flex items-center gap-0.5 text-sm ${monthlyChange >= 0 ? 'text-green-500' : 'text-red-500'}`}>
            {monthlyChange >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            <span>{monthlyChange}%</span>
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-1">vs. last month</p>
      </div>

      {/* Savings Progress */}
      <div className="mb-4 p-3 rounded-xl bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <PiggyBank className="w-4 h-4 text-cyan-500" />
            <span className="text-sm text-foreground">Savings Goal</span>
          </div>
          <span className="text-sm font-medium text-cyan-500">
            {Math.round((balance / savingsGoal) * 100)}%
          </span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full transition-all duration-500"
            style={{ width: `${Math.min((balance / savingsGoal) * 100, 100)}%` }}
          />
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          ${(savingsGoal - balance).toLocaleString()} to reach ${savingsGoal.toLocaleString()}
        </p>
      </div>

      {/* Recent Transactions */}
      <div>
        <p className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Recent Activity</p>
        <ul className="space-y-2">
          {transactions.map((tx) => (
            <li key={tx.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  tx.type === 'income' ? 'bg-green-500/10' : 'bg-red-500/10'
                }`}>
                  {tx.type === 'income' ? (
                    <ArrowUpRight className="w-4 h-4 text-green-500" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4 text-red-500" />
                  )}
                </div>
                <div>
                  <p className="text-sm text-foreground">{tx.description}</p>
                  <p className="text-xs text-muted-foreground">{tx.category} • {tx.date}</p>
                </div>
              </div>
              <span className={`text-sm font-medium ${
                tx.type === 'income' ? 'text-green-500' : 'text-foreground'
              }`}>
                {tx.type === 'income' ? '+' : '-'}${tx.amount.toFixed(2)}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default FinancialSnapshot;
