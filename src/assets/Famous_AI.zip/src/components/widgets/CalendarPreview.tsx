import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Users, Video, ChevronLeft, ChevronRight } from 'lucide-react';

interface Event {
  id: string;
  title: string;
  time: string;
  duration: string;
  type: 'meeting' | 'call' | 'task' | 'personal';
  location?: string;
  attendees?: number;
  isVideo?: boolean;
}

const CalendarPreview: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState(new Date());

  const events: Event[] = [
    { id: '1', title: 'Team Standup', time: '10:00 AM', duration: '30m', type: 'meeting', attendees: 8, isVideo: true },
    { id: '2', title: 'Client Call - Acme Corp', time: '2:00 PM', duration: '1h', type: 'call', isVideo: true },
    { id: '3', title: 'Product Review', time: '4:30 PM', duration: '45m', type: 'meeting', location: 'Room 3B', attendees: 5 },
  ];

  const typeColors = {
    meeting: 'bg-blue-500',
    call: 'bg-green-500',
    task: 'bg-amber-500',
    personal: 'bg-purple-500',
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
  };

  const navigateDate = (direction: number) => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + direction);
    setSelectedDate(newDate);
  };

  const isToday = selectedDate.toDateString() === new Date().toDateString();

  return (
    <div className="bg-card rounded-2xl border border-border p-5 card-hover">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-foreground">Calendar</h3>
          <p className="text-xs text-muted-foreground">Upcoming events</p>
        </div>
        <Calendar className="w-5 h-5 text-primary" />
      </div>

      {/* Date Navigator */}
      <div className="flex items-center justify-between mb-4 p-2 rounded-xl bg-muted/50">
        <button
          onClick={() => navigateDate(-1)}
          className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <div className="text-center">
          <p className="text-sm font-medium text-foreground">{formatDate(selectedDate)}</p>
          {isToday && <span className="text-xs text-primary">Today</span>}
        </div>
        <button
          onClick={() => navigateDate(1)}
          className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center transition-colors"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Events List */}
      <div className="space-y-3">
        {events.map((event) => (
          <div
            key={event.id}
            className="group relative flex gap-3 p-3 rounded-xl bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
          >
            {/* Time indicator */}
            <div className={`w-1 rounded-full ${typeColors[event.type]}`} />
            
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <h4 className="text-sm font-medium text-foreground truncate">{event.title}</h4>
                {event.isVideo && (
                  <Video className="w-4 h-4 text-primary flex-shrink-0" />
                )}
              </div>
              
              <div className="flex items-center gap-3 mt-1.5">
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">{event.time} • {event.duration}</span>
                </div>
                
                {event.location && (
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{event.location}</span>
                  </div>
                )}
                
                {event.attendees && (
                  <div className="flex items-center gap-1">
                    <Users className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{event.attendees}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Add */}
      <button className="w-full mt-4 py-2.5 rounded-xl border-2 border-dashed border-border hover:border-primary hover:bg-primary/5 text-sm text-muted-foreground hover:text-primary transition-all">
        + Add Event
      </button>
    </div>
  );
};

export default CalendarPreview;
