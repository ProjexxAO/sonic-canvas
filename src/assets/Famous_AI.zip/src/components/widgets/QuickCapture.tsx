import React, { useState } from 'react';
import { Mic, Type, Camera, Link2, FileText, Send, Sparkles } from 'lucide-react';

type CaptureType = 'text' | 'voice' | 'image' | 'link';

interface CapturedItem {
  id: string;
  type: CaptureType;
  content: string;
  timestamp: Date;
}

const QuickCapture: React.FC = () => {
  const [activeType, setActiveType] = useState<CaptureType>('text');
  const [inputValue, setInputValue] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recentCaptures, setRecentCaptures] = useState<CapturedItem[]>([
    { id: '1', type: 'text', content: 'Review project timeline with team', timestamp: new Date(Date.now() - 3600000) },
    { id: '2', type: 'link', content: 'https://figma.com/design-system', timestamp: new Date(Date.now() - 7200000) },
  ]);

  const captureTypes = [
    { type: 'text' as CaptureType, icon: Type, label: 'Text' },
    { type: 'voice' as CaptureType, icon: Mic, label: 'Voice' },
    { type: 'image' as CaptureType, icon: Camera, label: 'Image' },
    { type: 'link' as CaptureType, icon: Link2, label: 'Link' },
  ];

  const handleCapture = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newCapture: CapturedItem = {
      id: Date.now().toString(),
      type: activeType,
      content: inputValue,
      timestamp: new Date(),
    };

    setRecentCaptures([newCapture, ...recentCaptures.slice(0, 4)]);
    setInputValue('');
  };

  const handleVoiceCapture = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      // Simulate voice capture
      setTimeout(() => {
        const newCapture: CapturedItem = {
          id: Date.now().toString(),
          type: 'voice',
          content: 'Voice memo: Schedule dentist appointment',
          timestamp: new Date(),
        };
        setRecentCaptures([newCapture, ...recentCaptures.slice(0, 4)]);
        setIsRecording(false);
      }, 2000);
    }
  };

  const getTypeIcon = (type: CaptureType) => {
    const found = captureTypes.find(t => t.type === type);
    return found ? found.icon : FileText;
  };

  return (
    <div className="bg-card rounded-2xl border border-border p-5 card-hover">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-foreground">Quick Capture</h3>
          <p className="text-xs text-muted-foreground">Capture thoughts instantly</p>
        </div>
        <Sparkles className="w-5 h-5 text-primary" />
      </div>

      {/* Capture Type Selector */}
      <div className="flex gap-2 mb-4">
        {captureTypes.map(({ type, icon: Icon, label }) => (
          <button
            key={type}
            onClick={() => setActiveType(type)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg transition-all ${
              activeType === type
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted hover:bg-muted/80 text-muted-foreground'
            }`}
          >
            <Icon className="w-4 h-4" />
            <span className="text-xs font-medium hidden sm:inline">{label}</span>
          </button>
        ))}
      </div>

      {/* Input Area */}
      {activeType === 'voice' ? (
        <button
          onClick={handleVoiceCapture}
          className={`w-full py-8 rounded-xl border-2 border-dashed transition-all flex flex-col items-center justify-center gap-2 ${
            isRecording
              ? 'border-red-500 bg-red-500/10'
              : 'border-border hover:border-primary hover:bg-primary/5'
          }`}
        >
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
            isRecording ? 'bg-red-500 animate-pulse' : 'bg-primary'
          }`}>
            <Mic className="w-6 h-6 text-white" />
          </div>
          <span className="text-sm text-muted-foreground">
            {isRecording ? 'Recording... Tap to stop' : 'Tap to start recording'}
          </span>
          {isRecording && (
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className="w-1 bg-red-500 rounded-full animate-wave"
                  style={{ height: `${Math.random() * 20 + 10}px`, animationDelay: `${i * 100}ms` }}
                />
              ))}
            </div>
          )}
        </button>
      ) : (
        <form onSubmit={handleCapture} className="relative">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={
              activeType === 'text' ? 'Type a quick note...' :
              activeType === 'link' ? 'Paste a URL...' :
              'Describe the image...'
            }
            className="w-full bg-muted rounded-xl px-4 py-3 pr-12 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <button
            type="submit"
            disabled={!inputValue.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary/90 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      )}

      {/* Recent Captures */}
      {recentCaptures.length > 0 && (
        <div className="mt-4">
          <p className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Recent</p>
          <ul className="space-y-2">
            {recentCaptures.slice(0, 3).map((capture) => {
              const Icon = getTypeIcon(capture.type);
              return (
                <li key={capture.id} className="flex items-center gap-2 p-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors">
                  <div className="w-6 h-6 rounded bg-primary/10 flex items-center justify-center">
                    <Icon className="w-3 h-3 text-primary" />
                  </div>
                  <p className="text-xs text-foreground truncate flex-1">{capture.content}</p>
                  <span className="text-[10px] text-muted-foreground">
                    {capture.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
};

export default QuickCapture;
