import React, { useState } from 'react';
import { Image, Heart, Share2, ChevronLeft, ChevronRight, Calendar, MapPin } from 'lucide-react';

interface Memory {
  id: string;
  imageUrl: string;
  title: string;
  date: string;
  location: string;
  liked: boolean;
}

const PhotoMemories: React.FC = () => {
  const [memories, setMemories] = useState<Memory[]>([
    {
      id: '1',
      imageUrl: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop',
      title: 'Mountain Sunrise',
      date: '1 year ago',
      location: 'Swiss Alps',
      liked: true,
    },
    {
      id: '2',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop',
      title: 'Beach Sunset',
      date: '2 years ago',
      location: 'Maldives',
      liked: false,
    },
    {
      id: '3',
      imageUrl: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=400&h=300&fit=crop',
      title: 'Forest Trail',
      date: '3 years ago',
      location: 'Pacific Northwest',
      liked: true,
    },
  ]);

  const [currentIndex, setCurrentIndex] = useState(0);

  const toggleLike = (id: string) => {
    setMemories(memories.map(m =>
      m.id === id ? { ...m, liked: !m.liked } : m
    ));
  };

  const navigate = (direction: number) => {
    setCurrentIndex((prev) => {
      const next = prev + direction;
      if (next < 0) return memories.length - 1;
      if (next >= memories.length) return 0;
      return next;
    });
  };

  const currentMemory = memories[currentIndex];

  return (
    <div className="bg-card rounded-2xl border border-border overflow-hidden card-hover">
      {/* Image Container */}
      <div className="relative aspect-video">
        <img
          src={currentMemory.imageUrl}
          alt={currentMemory.title}
          className="w-full h-full object-cover"
        />
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        
        {/* Navigation Arrows */}
        <button
          onClick={() => navigate(-1)}
          className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/30 backdrop-blur hover:bg-black/50 flex items-center justify-center transition-colors"
        >
          <ChevronLeft className="w-4 h-4 text-white" />
        </button>
        <button
          onClick={() => navigate(1)}
          className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/30 backdrop-blur hover:bg-black/50 flex items-center justify-center transition-colors"
        >
          <ChevronRight className="w-4 h-4 text-white" />
        </button>

        {/* Memory Info Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h4 className="text-white font-semibold text-lg">{currentMemory.title}</h4>
          <div className="flex items-center gap-3 mt-1">
            <div className="flex items-center gap-1">
              <Calendar className="w-3 h-3 text-white/70" />
              <span className="text-xs text-white/70">{currentMemory.date}</span>
            </div>
            <div className="flex items-center gap-1">
              <MapPin className="w-3 h-3 text-white/70" />
              <span className="text-xs text-white/70">{currentMemory.location}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="absolute top-3 right-3 flex gap-2">
          <button
            onClick={() => toggleLike(currentMemory.id)}
            className={`w-8 h-8 rounded-full backdrop-blur flex items-center justify-center transition-colors ${
              currentMemory.liked ? 'bg-red-500' : 'bg-black/30 hover:bg-black/50'
            }`}
          >
            <Heart className={`w-4 h-4 ${currentMemory.liked ? 'text-white fill-white' : 'text-white'}`} />
          </button>
          <button className="w-8 h-8 rounded-full bg-black/30 backdrop-blur hover:bg-black/50 flex items-center justify-center transition-colors">
            <Share2 className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Dots Indicator */}
        <div className="absolute bottom-16 left-1/2 -translate-x-1/2 flex gap-1.5">
          {memories.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentIndex(i)}
              className={`w-2 h-2 rounded-full transition-all ${
                i === currentIndex ? 'bg-white w-4' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Image className="w-4 h-4 text-primary" />
          <span className="text-sm text-foreground">Photo Memories</span>
        </div>
        <span className="text-xs text-muted-foreground">On this day</span>
      </div>
    </div>
  );
};

export default PhotoMemories;
