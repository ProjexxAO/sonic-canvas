import React, { useState } from 'react';
import { Heart, Battery, Brain, Moon, Activity, Zap } from 'lucide-react';

interface Metric {
  id: string;
  label: string;
  value: number;
  max: number;
  icon: React.ElementType;
  color: string;
  unit?: string;
}

const WellnessScore: React.FC = () => {
  const [overallScore] = useState(78);

  const metrics: Metric[] = [
    { id: 'stress', label: 'Stress Level', value: 25, max: 100, icon: Brain, color: 'bg-purple-500', unit: 'Low' },
    { id: 'energy', label: 'Energy', value: 82, max: 100, icon: Zap, color: 'bg-amber-500', unit: 'High' },
    { id: 'sleep', label: 'Sleep Quality', value: 7.2, max: 10, icon: Moon, color: 'bg-indigo-500', unit: 'hrs' },
    { id: 'activity', label: 'Activity', value: 6500, max: 10000, icon: Activity, color: 'bg-green-500', unit: 'steps' },
  ];

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 60) return 'text-amber-500';
    return 'text-red-500';
  };

  const getScoreGradient = (score: number) => {
    if (score >= 80) return 'from-green-400 to-emerald-500';
    if (score >= 60) return 'from-amber-400 to-orange-500';
    return 'from-red-400 to-rose-500';
  };

  return (
    <div className="bg-card rounded-2xl border border-border p-5 card-hover">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-foreground">Wellness Score</h3>
          <p className="text-xs text-muted-foreground">Daily health metrics</p>
        </div>
        <Heart className="w-5 h-5 text-red-500" />
      </div>

      {/* Overall Score Circle */}
      <div className="flex items-center justify-center mb-6">
        <div className="relative w-32 h-32">
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="64"
              cy="64"
              r="56"
              fill="none"
              stroke="currentColor"
              strokeWidth="8"
              className="text-muted"
            />
            <circle
              cx="64"
              cy="64"
              r="56"
              fill="none"
              stroke="url(#scoreGradient)"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={`${(overallScore / 100) * 352} 352`}
              className="transition-all duration-1000"
            />
            <defs>
              <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#22d3ee" />
                <stop offset="100%" stopColor="#3b82f6" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className={`text-4xl font-bold ${getScoreColor(overallScore)}`}>{overallScore}</span>
            <span className="text-xs text-muted-foreground">out of 100</span>
          </div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 gap-3">
        {metrics.map((metric) => {
          const Icon = metric.icon;
          const percentage = (metric.value / metric.max) * 100;
          return (
            <div key={metric.id} className="p-3 rounded-xl bg-muted/50">
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-6 h-6 rounded-lg ${metric.color} flex items-center justify-center`}>
                  <Icon className="w-3 h-3 text-white" />
                </div>
                <span className="text-xs text-muted-foreground">{metric.label}</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-lg font-semibold text-foreground">
                  {metric.id === 'sleep' ? metric.value : metric.value.toLocaleString()}
                </span>
                <span className="text-xs text-muted-foreground">{metric.unit}</span>
              </div>
              <div className="h-1.5 bg-muted rounded-full mt-2 overflow-hidden">
                <div
                  className={`h-full ${metric.color} rounded-full transition-all duration-500`}
                  style={{ width: `${Math.min(percentage, 100)}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Recommendation */}
      <div className="mt-4 p-3 rounded-xl bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20">
        <p className="text-xs text-cyan-600 dark:text-cyan-400">
          <span className="font-semibold">Recommendation:</span> Take a 10-minute walk to boost your energy and reduce stress.
        </p>
      </div>
    </div>
  );
};

export default WellnessScore;
