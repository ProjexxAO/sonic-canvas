import React, { useState, useEffect, useCallback } from 'react';
import { Mic, MicOff, X, Send, Sparkles } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'atlas';
  content: string;
  timestamp: Date;
}

interface AtlasOrbProps {
  onCommand?: (command: string) => void;
}

const AtlasOrb: React.FC<AtlasOrbProps> = ({ onCommand }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'atlas',
      content: 'Hello! I\'m Atlas, your AI command center assistant. Say "Hey Atlas" or type a command to get started.',
      timestamp: new Date(),
    },
  ]);
  const [isProcessing, setIsProcessing] = useState(false);

  const quickCommands = [
    'Show my tasks',
    'Check finances',
    'Deploy agents',
    'Open inbox',
    'Start focus timer',
    'Show wellness score',
  ];

  const handleToggleExpand = () => {
    setIsExpanded(!isExpanded);
    if (isListening) setIsListening(false);
  };

  const handleToggleListening = () => {
    setIsListening(!isListening);
  };

  const processCommand = useCallback(async (command: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: command,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    setIsProcessing(true);

    // Simulate AI response
    setTimeout(() => {
      const responses: Record<string, string> = {
        'show my tasks': 'You have 5 tasks for today. Top priority: "Review Q4 budget proposal" due at 3 PM. Would you like me to open your task manager?',
        'check finances': 'Your current balance is $24,580.42. You\'re 12% under budget this month. Cash flow is positive with $3,200 projected savings.',
        'deploy agents': 'Ready to deploy agents. You have 144,000 agents across 11 domains. Which domain would you like to activate? Finance, Tech, Creative, or all?',
        'open inbox': 'Opening unified inbox. You have 23 unread messages: 8 require action, 12 are FYI, and 3 are archived suggestions.',
        'start focus timer': 'Focus timer started! ADHD support mode is enabled. I\'ll block distractions and remind you to take breaks every 25 minutes.',
        'show wellness score': 'Your wellness score is 78/100. Stress level: Low. Energy: High. Sleep quality last night: 7.2 hours. Recommendation: Take a 10-minute walk.',
      };

      const lowerCommand = command.toLowerCase();
      let response = 'I understand you want to ' + command + '. Let me help you with that. What specific action would you like me to take?';
      
      for (const [key, value] of Object.entries(responses)) {
        if (lowerCommand.includes(key)) {
          response = value;
          break;
        }
      }

      const atlasMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'atlas',
        content: response,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, atlasMessage]);
      setIsProcessing(false);
      onCommand?.(command);
    }, 1000);
  }, [onCommand]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;
    processCommand(inputValue);
    setInputValue('');
  };

  const handleQuickCommand = (command: string) => {
    processCommand(command);
  };

  // Simulate wake word detection
  useEffect(() => {
    if (isListening) {
      const timeout = setTimeout(() => {
        setIsListening(false);
        processCommand('Show my tasks');
      }, 3000);
      return () => clearTimeout(timeout);
    }
  }, [isListening, processCommand]);

  return (
    <>
      {/* Floating Orb */}
      <button
        onClick={handleToggleExpand}
        className={`fixed bottom-6 right-6 z-50 w-16 h-16 rounded-full bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 flex items-center justify-center transition-all duration-500 ${
          isExpanded ? 'scale-0 opacity-0' : 'scale-100 opacity-100 animate-pulse-glow hover:scale-110'
        }`}
      >
        <Sparkles className="w-8 h-8 text-white" />
      </button>

      {/* Expanded Panel */}
      <div
        className={`fixed bottom-6 right-6 z-50 w-96 bg-card border border-border rounded-2xl shadow-2xl transition-all duration-500 overflow-hidden ${
          isExpanded ? 'scale-100 opacity-100' : 'scale-0 opacity-0 pointer-events-none'
        }`}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-600 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Atlas</h3>
              <p className="text-xs text-white/70">AI Command Center</p>
            </div>
          </div>
          <button
            onClick={handleToggleExpand}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Messages */}
        <div className="h-64 overflow-y-auto p-4 space-y-3">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                  message.role === 'user'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-foreground'
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <p className="text-[10px] opacity-60 mt-1">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
          {isProcessing && (
            <div className="flex justify-start">
              <div className="bg-muted rounded-2xl px-4 py-3">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Quick Commands */}
        <div className="px-4 pb-2">
          <div className="flex flex-wrap gap-2">
            {quickCommands.slice(0, 3).map((cmd) => (
              <button
                key={cmd}
                onClick={() => handleQuickCommand(cmd)}
                className="text-xs px-3 py-1.5 rounded-full bg-muted hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                {cmd}
              </button>
            ))}
          </div>
        </div>

        {/* Input */}
        <form onSubmit={handleSubmit} className="p-4 border-t border-border flex gap-2">
          <button
            type="button"
            onClick={handleToggleListening}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
              isListening
                ? 'bg-red-500 text-white animate-pulse'
                : 'bg-muted hover:bg-primary hover:text-primary-foreground'
            }`}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={isListening ? 'Listening...' : 'Type a command...'}
            className="flex-1 bg-muted rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <button
            type="submit"
            disabled={!inputValue.trim()}
            className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary/90 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        {/* Voice Waveform */}
        {isListening && (
          <div className="absolute bottom-24 left-1/2 -translate-x-1/2 flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="w-1 bg-primary rounded-full animate-wave"
                style={{
                  height: `${Math.random() * 20 + 10}px`,
                  animationDelay: `${i * 100}ms`,
                }}
              />
            ))}
          </div>
        )}
      </div>
    </>
  );
};

export default AtlasOrb;
