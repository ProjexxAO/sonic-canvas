import React, { useState } from 'react';
import { 
  Building2, TrendingUp, TrendingDown, Users, DollarSign,
  BarChart3, PieChart, Activity, Globe, Shield, Clock,
  ChevronDown, ArrowUpRight, ArrowDownRight
} from 'lucide-react';

type Persona = 'ceo' | 'cfo' | 'cto' | 'coo';

const EnterpriseDashboard: React.FC = () => {
  const [activePersona, setActivePersona] = useState<Persona>('ceo');

  const personas = [
    { id: 'ceo' as Persona, label: 'CEO View', icon: Building2 },
    { id: 'cfo' as Persona, label: 'CFO View', icon: DollarSign },
    { id: 'cto' as Persona, label: 'CTO View', icon: BarChart3 },
    { id: 'coo' as Persona, label: 'COO View', icon: Activity },
  ];

  const ceoMetrics = [
    { label: 'Revenue YTD', value: '$12.4M', change: '+18%', isPositive: true },
    { label: 'Active Customers', value: '2,847', change: '+12%', isPositive: true },
    { label: 'Employee Count', value: '156', change: '+8', isPositive: true },
    { label: 'NPS Score', value: '72', change: '+5', isPositive: true },
  ];

  const cfoMetrics = [
    { label: 'Gross Margin', value: '68.5%', change: '+2.3%', isPositive: true },
    { label: 'Operating Expenses', value: '$4.2M', change: '-5%', isPositive: true },
    { label: 'Cash Runway', value: '18 mo', change: '+3 mo', isPositive: true },
    { label: 'Burn Rate', value: '$420K', change: '-12%', isPositive: true },
  ];

  const ctoMetrics = [
    { label: 'System Uptime', value: '99.97%', change: '+0.02%', isPositive: true },
    { label: 'Deploy Frequency', value: '12/day', change: '+3', isPositive: true },
    { label: 'Bug Resolution', value: '4.2 hrs', change: '-1.5 hrs', isPositive: true },
    { label: 'Tech Debt Score', value: 'B+', change: 'from B', isPositive: true },
  ];

  const cooMetrics = [
    { label: 'Operational Efficiency', value: '94%', change: '+3%', isPositive: true },
    { label: 'Process Automation', value: '78%', change: '+12%', isPositive: true },
    { label: 'Vendor Compliance', value: '100%', change: 'maintained', isPositive: true },
    { label: 'Cost per Unit', value: '$24.50', change: '-8%', isPositive: true },
  ];

  const getMetrics = () => {
    switch (activePersona) {
      case 'ceo': return ceoMetrics;
      case 'cfo': return cfoMetrics;
      case 'cto': return ctoMetrics;
      case 'coo': return cooMetrics;
      default: return ceoMetrics;
    }
  };

  const departmentPerformance = [
    { name: 'Engineering', score: 92, trend: 'up', headcount: 45 },
    { name: 'Sales', score: 88, trend: 'up', headcount: 32 },
    { name: 'Marketing', score: 85, trend: 'stable', headcount: 18 },
    { name: 'Operations', score: 90, trend: 'up', headcount: 24 },
    { name: 'Finance', score: 94, trend: 'up', headcount: 12 },
    { name: 'HR', score: 87, trend: 'stable', headcount: 8 },
  ];

  const revenueByRegion = [
    { region: 'North America', revenue: 6.2, percentage: 50, color: 'bg-blue-500' },
    { region: 'Europe', revenue: 3.1, percentage: 25, color: 'bg-green-500' },
    { region: 'Asia Pacific', revenue: 2.2, percentage: 18, color: 'bg-purple-500' },
    { region: 'Other', revenue: 0.9, percentage: 7, color: 'bg-amber-500' },
  ];

  const keyInitiatives = [
    { name: 'Product Launch Q1', status: 'on-track', progress: 75, owner: 'Product' },
    { name: 'Market Expansion EU', status: 'at-risk', progress: 45, owner: 'Sales' },
    { name: 'Platform Migration', status: 'on-track', progress: 60, owner: 'Engineering' },
    { name: 'Cost Optimization', status: 'ahead', progress: 90, owner: 'Operations' },
  ];

  const statusColors = {
    'on-track': 'text-green-500 bg-green-500/10',
    'at-risk': 'text-red-500 bg-red-500/10',
    'ahead': 'text-blue-500 bg-blue-500/10',
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Executive Intelligence</h2>
          <p className="text-sm text-muted-foreground">C-Suite dashboard with real-time business metrics</p>
        </div>
        <div className="flex items-center gap-2">
          {personas.map((persona) => {
            const Icon = persona.icon;
            return (
              <button
                key={persona.id}
                onClick={() => setActivePersona(persona.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
                  activePersona === persona.id
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-card border border-border hover:bg-muted'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-sm font-medium">{persona.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {getMetrics().map((metric) => (
          <div key={metric.label} className="bg-card rounded-2xl border border-border p-5">
            <p className="text-sm text-muted-foreground mb-2">{metric.label}</p>
            <div className="flex items-end justify-between">
              <p className="metric-value text-foreground">{metric.value}</p>
              <div className={`flex items-center gap-1 ${metric.isPositive ? 'text-green-500' : 'text-red-500'}`}>
                {metric.isPositive ? (
                  <ArrowUpRight className="w-4 h-4" />
                ) : (
                  <ArrowDownRight className="w-4 h-4" />
                )}
                <span className="text-sm font-medium">{metric.change}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0">
        {/* Department Performance */}
        <div className="lg:col-span-1 bg-card rounded-2xl border border-border p-5 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">Department Performance</h3>
            <Users className="w-5 h-5 text-muted-foreground" />
          </div>
          <div className="flex-1 overflow-y-auto space-y-3">
            {departmentPerformance.map((dept) => (
              <div key={dept.name} className="p-3 rounded-xl bg-muted/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">{dept.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{dept.headcount} people</span>
                    {dept.trend === 'up' && <TrendingUp className="w-3 h-3 text-green-500" />}
                    {dept.trend === 'down' && <TrendingDown className="w-3 h-3 text-red-500" />}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"
                      style={{ width: `${dept.score}%` }}
                    />
                  </div>
                  <span className="text-sm font-semibold text-foreground">{dept.score}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Revenue by Region */}
        <div className="lg:col-span-1 bg-card rounded-2xl border border-border p-5 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">Revenue by Region</h3>
            <Globe className="w-5 h-5 text-muted-foreground" />
          </div>
          
          {/* Donut Chart Placeholder */}
          <div className="flex items-center justify-center mb-4">
            <div className="relative w-32 h-32">
              <svg className="w-full h-full transform -rotate-90">
                {revenueByRegion.map((region, index) => {
                  const offset = revenueByRegion.slice(0, index).reduce((acc, r) => acc + r.percentage, 0);
                  return (
                    <circle
                      key={region.region}
                      cx="64"
                      cy="64"
                      r="48"
                      fill="none"
                      stroke={region.color.replace('bg-', 'var(--')}
                      strokeWidth="16"
                      strokeDasharray={`${region.percentage * 3.01} 301`}
                      strokeDashoffset={`${-offset * 3.01}`}
                      className={region.color.replace('bg-', 'stroke-')}
                    />
                  );
                })}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-bold text-foreground">$12.4M</span>
                <span className="text-xs text-muted-foreground">Total</span>
              </div>
            </div>
          </div>

          <div className="flex-1 space-y-2">
            {revenueByRegion.map((region) => (
              <div key={region.region} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${region.color}`} />
                  <span className="text-sm text-foreground">{region.region}</span>
                </div>
                <div className="text-right">
                  <span className="text-sm font-medium text-foreground">${region.revenue}M</span>
                  <span className="text-xs text-muted-foreground ml-2">({region.percentage}%)</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Key Initiatives */}
        <div className="lg:col-span-1 bg-card rounded-2xl border border-border p-5 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">Key Initiatives</h3>
            <Activity className="w-5 h-5 text-muted-foreground" />
          </div>
          <div className="flex-1 overflow-y-auto space-y-3">
            {keyInitiatives.map((initiative) => (
              <div key={initiative.name} className="p-3 rounded-xl bg-muted/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">{initiative.name}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${statusColors[initiative.status as keyof typeof statusColors]}`}>
                    {initiative.status.replace('-', ' ')}
                  </span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden mb-2">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      initiative.status === 'at-risk' ? 'bg-red-500' :
                      initiative.status === 'ahead' ? 'bg-blue-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${initiative.progress}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{initiative.progress}% complete</span>
                  <span>Owner: {initiative.owner}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnterpriseDashboard;
