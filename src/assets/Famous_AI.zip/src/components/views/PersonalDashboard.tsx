import React from 'react';
import TodaysFocus from '../widgets/TodaysFocus';
import HabitTracker from '../widgets/HabitTracker';
import FinancialSnapshot from '../widgets/FinancialSnapshot';
import WellnessScore from '../widgets/WellnessScore';
import QuickCapture from '../widgets/QuickCapture';
import CalendarPreview from '../widgets/CalendarPreview';
import GoalProgress from '../widgets/GoalProgress';
import PhotoMemories from '../widgets/PhotoMemories';
import { Sparkles, TrendingUp, Clock, Target, LogIn } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface PersonalDashboardProps {
  onOpenAuth?: () => void;
}

const PersonalDashboard: React.FC<PersonalDashboardProps> = ({ onOpenAuth }) => {
  const { user, isAuthenticated } = useAuth();

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const getUserName = () => {
    if (user?.fullName) {
      return user.fullName.split(' ')[0];
    }
    return 'there';
  };

  const stats = [
    { label: 'Tasks Completed', value: '12', change: '+3 today', icon: Target, color: 'text-green-500' },
    { label: 'Focus Time', value: '4.5h', change: '+1.2h vs avg', icon: Clock, color: 'text-blue-500' },
    { label: 'Wellness Score', value: '78', change: '+5 this week', icon: TrendingUp, color: 'text-purple-500' },
  ];

  return (
    <div className="h-full flex flex-col">
      {/* Welcome Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              {greeting()}, {getUserName()}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              {isAuthenticated 
                ? "Here's what's happening in your world today"
                : "Sign in to sync your data across devices"
              }
            </p>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20">
            <Sparkles className="w-4 h-4 text-cyan-500" />
            <span className="text-sm text-cyan-600 dark:text-cyan-400">
              Atlas is ready to help
            </span>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 mt-4">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <div key={stat.label} className="bg-card rounded-xl border border-border p-4 flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl bg-muted flex items-center justify-center ${stat.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{stat.label}</span>
                    <span className="text-xs text-green-500">{stat.change}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Widget Grid */}
      <div className="flex-1 overflow-y-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Row 1 */}
          <div className="lg:col-span-1">
            <TodaysFocus />
          </div>
          <div className="lg:col-span-1">
            <CalendarPreview />
          </div>
          <div className="lg:col-span-1">
            <WellnessScore />
          </div>

          {/* Row 2 */}
          <div className="lg:col-span-2">
            <HabitTracker />
          </div>
          <div className="lg:col-span-1">
            <QuickCapture />
          </div>

          {/* Row 3 */}
          <div className="lg:col-span-1">
            <FinancialSnapshot />
          </div>
          <div className="lg:col-span-1">
            <GoalProgress />
          </div>
          <div className="lg:col-span-1">
            <PhotoMemories />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PersonalDashboard;
