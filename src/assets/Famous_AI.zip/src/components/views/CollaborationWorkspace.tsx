import React, { useState } from 'react';
import { 
  FolderKanban, Users, MessageSquare, FileText, Plus, Search,
  MoreHorizontal, Clock, CheckCircle2, AlertCircle, Star,
  Send, Paperclip, Image, Smile, AtSign, Hash, Lock,
  ChevronRight, Download, Eye, Edit, Trash2, History
} from 'lucide-react';

type Tab = 'workspaces' | 'chat' | 'files';
type Role = 'admin' | 'editor' | 'viewer';

interface Workspace {
  id: string;
  name: string;
  description: string;
  members: number;
  lastActivity: string;
  isStarred: boolean;
  template: string;
}

interface ChatMessage {
  id: string;
  sender: string;
  avatar: string;
  content: string;
  timestamp: string;
  mentions?: string[];
}

interface SharedFile {
  id: string;
  name: string;
  type: 'document' | 'spreadsheet' | 'presentation' | 'image';
  size: string;
  lastModified: string;
  modifiedBy: string;
  versions: number;
}

interface TeamMember {
  id: string;
  name: string;
  avatar: string;
  role: Role;
  status: 'online' | 'away' | 'offline';
}

const CollaborationWorkspace: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('workspaces');
  const [searchQuery, setSearchQuery] = useState('');
  const [chatMessage, setChatMessage] = useState('');
  const [selectedWorkspace, setSelectedWorkspace] = useState<string | null>(null);

  const workspaces: Workspace[] = [
    { id: '1', name: 'Q4 Marketing Campaign', description: 'Planning and execution of Q4 marketing initiatives', members: 8, lastActivity: '2 min ago', isStarred: true, template: 'Marketing' },
    { id: '2', name: 'Product Roadmap 2026', description: 'Strategic planning for next year\'s product development', members: 12, lastActivity: '15 min ago', isStarred: true, template: 'Product' },
    { id: '3', name: 'Engineering Sprint 42', description: 'Current sprint tasks and bug fixes', members: 6, lastActivity: '1 hr ago', isStarred: false, template: 'Engineering' },
    { id: '4', name: 'Sales Pipeline Review', description: 'Weekly sales pipeline and forecast analysis', members: 5, lastActivity: '3 hrs ago', isStarred: false, template: 'Sales' },
    { id: '5', name: 'HR Onboarding', description: 'New employee onboarding materials and checklists', members: 4, lastActivity: '1 day ago', isStarred: false, template: 'HR' },
    { id: '6', name: 'Finance Budget Planning', description: 'Annual budget allocation and tracking', members: 7, lastActivity: '2 days ago', isStarred: true, template: 'Finance' },
  ];

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: '1', sender: 'Sarah Johnson', avatar: 'SJ', content: 'Hey team! I\'ve uploaded the latest design mockups to the files section. Please review when you get a chance.', timestamp: '10:30 AM' },
    { id: '2', sender: 'Mike Chen', avatar: 'MC', content: 'Thanks @Sarah! I\'ll take a look this afternoon. @David can you also review the technical feasibility?', timestamp: '10:35 AM', mentions: ['Sarah', 'David'] },
    { id: '3', sender: 'David Park', avatar: 'DP', content: 'Sure thing! I\'ll have feedback by EOD.', timestamp: '10:42 AM' },
    { id: '4', sender: 'Emily Rodriguez', avatar: 'ER', content: 'Great progress everyone! Let\'s sync up tomorrow at 2 PM to discuss next steps.', timestamp: '11:15 AM' },
  ]);

  const sharedFiles: SharedFile[] = [
    { id: '1', name: 'Q4 Marketing Strategy.docx', type: 'document', size: '2.4 MB', lastModified: '2 hrs ago', modifiedBy: 'Sarah Johnson', versions: 8 },
    { id: '2', name: 'Budget Forecast 2026.xlsx', type: 'spreadsheet', size: '1.8 MB', lastModified: '5 hrs ago', modifiedBy: 'Mike Chen', versions: 12 },
    { id: '3', name: 'Product Roadmap.pptx', type: 'presentation', size: '15.2 MB', lastModified: '1 day ago', modifiedBy: 'David Park', versions: 5 },
    { id: '4', name: 'Brand Guidelines.pdf', type: 'document', size: '8.5 MB', lastModified: '3 days ago', modifiedBy: 'Emily Rodriguez', versions: 3 },
    { id: '5', name: 'Team Photo.jpg', type: 'image', size: '4.2 MB', lastModified: '1 week ago', modifiedBy: 'Sarah Johnson', versions: 1 },
  ];

  const teamMembers: TeamMember[] = [
    { id: '1', name: 'Sarah Johnson', avatar: 'SJ', role: 'admin', status: 'online' },
    { id: '2', name: 'Mike Chen', avatar: 'MC', role: 'editor', status: 'online' },
    { id: '3', name: 'David Park', avatar: 'DP', role: 'editor', status: 'away' },
    { id: '4', name: 'Emily Rodriguez', avatar: 'ER', role: 'admin', status: 'online' },
    { id: '5', name: 'Alex Kim', avatar: 'AK', role: 'viewer', status: 'offline' },
  ];

  const templates = ['Marketing', 'Product', 'Engineering', 'Sales', 'HR', 'Finance'];

  const fileTypeIcons = {
    document: FileText,
    spreadsheet: FileText,
    presentation: FileText,
    image: Image,
  };

  const fileTypeColors = {
    document: 'bg-blue-500',
    spreadsheet: 'bg-green-500',
    presentation: 'bg-orange-500',
    image: 'bg-purple-500',
  };

  const roleColors = {
    admin: 'bg-red-500/10 text-red-500',
    editor: 'bg-blue-500/10 text-blue-500',
    viewer: 'bg-muted text-muted-foreground',
  };

  const statusColors = {
    online: 'bg-green-500',
    away: 'bg-amber-500',
    offline: 'bg-muted-foreground',
  };

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;
    
    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: 'You',
      avatar: 'JD',
      content: chatMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    
    setChatMessages([...chatMessages, newMessage]);
    setChatMessage('');
  };

  const toggleWorkspaceStar = (id: string) => {
    // In a real app, this would update state
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Collaboration Workspace</h2>
          <p className="text-sm text-muted-foreground">{workspaces.length} workspaces • {teamMembers.filter(m => m.status === 'online').length} members online</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors">
          <Plus className="w-4 h-4" />
          New Workspace
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {[
          { id: 'workspaces' as Tab, label: 'Workspaces', icon: FolderKanban },
          { id: 'chat' as Tab, label: 'Team Chat', icon: MessageSquare },
          { id: 'files' as Tab, label: 'Shared Files', icon: FileText },
        ].map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === id
                ? 'bg-primary text-primary-foreground'
                : 'bg-card border border-border hover:bg-muted'
            }`}
          >
            <Icon className="w-4 h-4" />
            <span className="text-sm font-medium">{label}</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 flex gap-6 min-h-0">
        {/* Main Content */}
        <div className="flex-1 flex flex-col min-h-0">
          {activeTab === 'workspaces' && (
            <>
              {/* Search */}
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search workspaces..."
                  className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              {/* Templates */}
              <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
                {templates.map((template) => (
                  <button
                    key={template}
                    className="px-3 py-1.5 rounded-lg bg-muted hover:bg-primary hover:text-primary-foreground text-sm whitespace-nowrap transition-colors"
                  >
                    {template}
                  </button>
                ))}
              </div>

              {/* Workspaces Grid */}
              <div className="flex-1 overflow-y-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {workspaces.map((workspace) => (
                    <div
                      key={workspace.id}
                      className="bg-card rounded-2xl border border-border p-5 hover:border-primary/50 transition-all cursor-pointer"
                      onClick={() => setSelectedWorkspace(workspace.id)}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center">
                            <FolderKanban className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-foreground">{workspace.name}</h4>
                            <span className="text-xs text-muted-foreground">{workspace.template}</span>
                          </div>
                        </div>
                        <button className="p-1.5 rounded-lg hover:bg-muted transition-colors">
                          <Star className={`w-4 h-4 ${workspace.isStarred ? 'text-amber-500 fill-amber-500' : 'text-muted-foreground'}`} />
                        </button>
                      </div>
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{workspace.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-1">
                            <Users className="w-4 h-4 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">{workspace.members}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">{workspace.lastActivity}</span>
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-muted-foreground" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeTab === 'chat' && (
            <div className="flex-1 flex flex-col bg-card rounded-2xl border border-border overflow-hidden">
              {/* Chat Header */}
              <div className="p-4 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Hash className="w-5 h-5 text-muted-foreground" />
                  <span className="font-semibold text-foreground">general</span>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 rounded-lg hover:bg-muted transition-colors">
                    <Users className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {chatMessages.map((msg) => (
                  <div key={msg.id} className="flex gap-3">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white text-sm font-medium flex-shrink-0">
                      {msg.avatar}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-foreground text-sm">{msg.sender}</span>
                        <span className="text-xs text-muted-foreground">{msg.timestamp}</span>
                      </div>
                      <p className="text-sm text-foreground">{msg.content}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Message Input */}
              <form onSubmit={sendMessage} className="p-4 border-t border-border">
                <div className="flex items-center gap-2">
                  <button type="button" className="p-2 rounded-lg hover:bg-muted transition-colors">
                    <Paperclip className="w-4 h-4 text-muted-foreground" />
                  </button>
                  <input
                    type="text"
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    placeholder="Type a message..."
                    className="flex-1 bg-muted rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                  <button type="button" className="p-2 rounded-lg hover:bg-muted transition-colors">
                    <AtSign className="w-4 h-4 text-muted-foreground" />
                  </button>
                  <button type="button" className="p-2 rounded-lg hover:bg-muted transition-colors">
                    <Smile className="w-4 h-4 text-muted-foreground" />
                  </button>
                  <button
                    type="submit"
                    disabled={!chatMessage.trim()}
                    className="p-2 rounded-lg bg-primary text-primary-foreground disabled:opacity-50 hover:bg-primary/90 transition-colors"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </form>
            </div>
          )}

          {activeTab === 'files' && (
            <>
              {/* Search */}
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search files..."
                  className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              {/* Files List */}
              <div className="flex-1 bg-card rounded-2xl border border-border overflow-hidden">
                <div className="divide-y divide-border">
                  {sharedFiles.map((file) => {
                    const FileIcon = fileTypeIcons[file.type];
                    return (
                      <div key={file.id} className="flex items-center gap-4 p-4 hover:bg-muted/50 transition-colors">
                        <div className={`w-10 h-10 rounded-xl ${fileTypeColors[file.type]} flex items-center justify-center`}>
                          <FileIcon className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">{file.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {file.size} • Modified {file.lastModified} by {file.modifiedBy}
                          </p>
                        </div>
                        <div className="flex items-center gap-1">
                          <History className="w-3 h-3 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">{file.versions} versions</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <button className="p-2 rounded-lg hover:bg-muted transition-colors">
                            <Eye className="w-4 h-4 text-muted-foreground" />
                          </button>
                          <button className="p-2 rounded-lg hover:bg-muted transition-colors">
                            <Download className="w-4 h-4 text-muted-foreground" />
                          </button>
                          <button className="p-2 rounded-lg hover:bg-muted transition-colors">
                            <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Team Members Sidebar */}
        <div className="w-64 bg-card rounded-2xl border border-border p-4 hidden lg:block">
          <h3 className="font-semibold text-foreground mb-4">Team Members</h3>
          <div className="space-y-3">
            {teamMembers.map((member) => (
              <div key={member.id} className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white text-sm font-medium">
                    {member.avatar}
                  </div>
                  <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-card ${statusColors[member.status]}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{member.name}</p>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${roleColors[member.role]}`}>
                    {member.role}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Permissions */}
          <div className="mt-6 pt-4 border-t border-border">
            <h4 className="text-sm font-medium text-foreground mb-3">Permissions</h4>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Admin</span>
                <span className="text-foreground">Full access</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Editor</span>
                <span className="text-foreground">Edit & comment</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Viewer</span>
                <span className="text-foreground">View only</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CollaborationWorkspace;
