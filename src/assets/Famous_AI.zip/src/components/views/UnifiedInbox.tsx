import React, { useState } from 'react';
import { 
  Mail, MessageSquare, Phone, Search, Filter, Star, Archive, 
  Trash2, CheckCircle2, Clock, AlertCircle, ChevronDown, 
  MoreHorizontal, Reply, Forward, Tag
} from 'lucide-react';

type Platform = 'all' | 'gmail' | 'slack' | 'whatsapp' | 'sms';
type Category = 'all' | 'action' | 'fyi' | 'archived';

interface Message {
  id: string;
  platform: 'gmail' | 'slack' | 'whatsapp' | 'sms';
  sender: string;
  senderAvatar?: string;
  subject?: string;
  preview: string;
  timestamp: string;
  category: 'action' | 'fyi' | 'archived';
  isStarred: boolean;
  isRead: boolean;
}

const UnifiedInbox: React.FC = () => {
  const [activePlatform, setActivePlatform] = useState<Platform>('all');
  const [activeCategory, setActiveCategory] = useState<Category>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMessages, setSelectedMessages] = useState<string[]>([]);

  const [messages, setMessages] = useState<Message[]>([
    { id: '1', platform: 'gmail', sender: 'Sarah Johnson', subject: 'Q4 Budget Review - Action Required', preview: 'Hi, I\'ve attached the Q4 budget proposal for your review. Please provide feedback by EOD...', timestamp: '10:30 AM', category: 'action', isStarred: true, isRead: false },
    { id: '2', platform: 'slack', sender: '#engineering', subject: 'Deployment Complete', preview: 'The v2.5.0 release has been successfully deployed to production. All systems are operational...', timestamp: '9:45 AM', category: 'fyi', isStarred: false, isRead: true },
    { id: '3', platform: 'whatsapp', sender: 'Mom', preview: 'Don\'t forget dinner on Sunday! Your dad is making his famous lasagna 🍝', timestamp: '9:15 AM', category: 'fyi', isStarred: true, isRead: false },
    { id: '4', platform: 'gmail', sender: 'LinkedIn', subject: 'New connection request', preview: 'John Smith wants to connect with you on LinkedIn...', timestamp: 'Yesterday', category: 'fyi', isStarred: false, isRead: true },
    { id: '5', platform: 'sms', sender: '+1 555-0123', preview: 'Your package has been delivered. Thank you for shopping with us!', timestamp: 'Yesterday', category: 'fyi', isStarred: false, isRead: true },
    { id: '6', platform: 'gmail', sender: 'HR Department', subject: 'Benefits Enrollment Deadline', preview: 'This is a reminder that the benefits enrollment deadline is approaching. Please complete...', timestamp: 'Yesterday', category: 'action', isStarred: false, isRead: false },
    { id: '7', platform: 'slack', sender: '@mike.chen', subject: 'Code Review Request', preview: 'Hey, can you take a look at PR #342? It\'s the new authentication flow...', timestamp: '2 days ago', category: 'action', isStarred: false, isRead: true },
    { id: '8', platform: 'whatsapp', sender: 'Team Lunch Group', preview: 'Where should we go for lunch today? I\'m thinking Thai food...', timestamp: '2 days ago', category: 'fyi', isStarred: false, isRead: true },
  ]);

  const platforms = [
    { id: 'all' as Platform, label: 'All', icon: Mail, count: messages.length },
    { id: 'gmail' as Platform, label: 'Gmail', icon: Mail, count: messages.filter(m => m.platform === 'gmail').length },
    { id: 'slack' as Platform, label: 'Slack', icon: MessageSquare, count: messages.filter(m => m.platform === 'slack').length },
    { id: 'whatsapp' as Platform, label: 'WhatsApp', icon: Phone, count: messages.filter(m => m.platform === 'whatsapp').length },
    { id: 'sms' as Platform, label: 'SMS', icon: Phone, count: messages.filter(m => m.platform === 'sms').length },
  ];

  const categories = [
    { id: 'all' as Category, label: 'All Messages', icon: Mail, color: 'text-foreground' },
    { id: 'action' as Category, label: 'Action Required', icon: AlertCircle, color: 'text-red-500' },
    { id: 'fyi' as Category, label: 'FYI', icon: Clock, color: 'text-blue-500' },
    { id: 'archived' as Category, label: 'Archived', icon: Archive, color: 'text-muted-foreground' },
  ];

  const platformColors = {
    gmail: 'bg-red-500',
    slack: 'bg-purple-500',
    whatsapp: 'bg-green-500',
    sms: 'bg-blue-500',
  };

  const filteredMessages = messages.filter(m => {
    if (activePlatform !== 'all' && m.platform !== activePlatform) return false;
    if (activeCategory !== 'all' && m.category !== activeCategory) return false;
    if (searchQuery && !m.sender.toLowerCase().includes(searchQuery.toLowerCase()) && 
        !m.preview.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !(m.subject?.toLowerCase().includes(searchQuery.toLowerCase()))) return false;
    return true;
  });

  const toggleStar = (id: string) => {
    setMessages(messages.map(m => m.id === id ? { ...m, isStarred: !m.isStarred } : m));
  };

  const markAsRead = (id: string) => {
    setMessages(messages.map(m => m.id === id ? { ...m, isRead: true } : m));
  };

  const toggleSelect = (id: string) => {
    setSelectedMessages(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const unreadCount = messages.filter(m => !m.isRead).length;

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Unified Inbox</h2>
          <p className="text-sm text-muted-foreground">{unreadCount} unread messages across all platforms</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-4 py-2 rounded-xl bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors">
            Compose
          </button>
        </div>
      </div>

      {/* Platform Tabs */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
        {platforms.map(({ id, label, icon: Icon, count }) => (
          <button
            key={id}
            onClick={() => setActivePlatform(id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
              activePlatform === id
                ? 'bg-primary text-primary-foreground'
                : 'bg-card border border-border hover:bg-muted'
            }`}
          >
            <Icon className="w-4 h-4" />
            <span className="text-sm font-medium">{label}</span>
            <span className={`text-xs px-1.5 py-0.5 rounded-full ${
              activePlatform === id ? 'bg-white/20' : 'bg-muted'
            }`}>
              {count}
            </span>
          </button>
        ))}
      </div>

      {/* Search and Filter */}
      <div className="flex gap-3 mb-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search messages..."
            className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <div className="flex gap-2">
          {categories.map(({ id, label, icon: Icon, color }) => (
            <button
              key={id}
              onClick={() => setActiveCategory(id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl transition-all ${
                activeCategory === id
                  ? 'bg-primary/10 border border-primary'
                  : 'bg-card border border-border hover:bg-muted'
              }`}
            >
              <Icon className={`w-4 h-4 ${activeCategory === id ? 'text-primary' : color}`} />
              <span className="text-sm hidden lg:inline">{label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Messages List */}
      <div className="flex-1 bg-card rounded-2xl border border-border overflow-hidden">
        <div className="divide-y divide-border">
          {filteredMessages.map((message) => (
            <div
              key={message.id}
              onClick={() => markAsRead(message.id)}
              className={`flex items-start gap-4 p-4 hover:bg-muted/50 cursor-pointer transition-colors ${
                !message.isRead ? 'bg-primary/5' : ''
              }`}
            >
              {/* Checkbox */}
              <button
                onClick={(e) => { e.stopPropagation(); toggleSelect(message.id); }}
                className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
                  selectedMessages.includes(message.id)
                    ? 'bg-primary border-primary'
                    : 'border-border hover:border-primary'
                }`}
              >
                {selectedMessages.includes(message.id) && (
                  <CheckCircle2 className="w-3 h-3 text-white" />
                )}
              </button>

              {/* Platform Indicator */}
              <div className={`w-8 h-8 rounded-lg ${platformColors[message.platform]} flex items-center justify-center flex-shrink-0`}>
                {message.platform === 'gmail' && <Mail className="w-4 h-4 text-white" />}
                {message.platform === 'slack' && <MessageSquare className="w-4 h-4 text-white" />}
                {message.platform === 'whatsapp' && <Phone className="w-4 h-4 text-white" />}
                {message.platform === 'sms' && <Phone className="w-4 h-4 text-white" />}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-sm ${!message.isRead ? 'font-semibold text-foreground' : 'text-foreground'}`}>
                    {message.sender}
                  </span>
                  {message.category === 'action' && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-red-500/10 text-red-500 font-medium">
                      Action Required
                    </span>
                  )}
                </div>
                {message.subject && (
                  <p className={`text-sm mb-0.5 ${!message.isRead ? 'font-medium text-foreground' : 'text-muted-foreground'}`}>
                    {message.subject}
                  </p>
                )}
                <p className="text-sm text-muted-foreground truncate">{message.preview}</p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground whitespace-nowrap">{message.timestamp}</span>
                <button
                  onClick={(e) => { e.stopPropagation(); toggleStar(message.id); }}
                  className="p-1 hover:bg-muted rounded transition-colors"
                >
                  <Star className={`w-4 h-4 ${message.isStarred ? 'text-amber-500 fill-amber-500' : 'text-muted-foreground'}`} />
                </button>
                <button className="p-1 hover:bg-muted rounded transition-colors">
                  <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UnifiedInbox;
