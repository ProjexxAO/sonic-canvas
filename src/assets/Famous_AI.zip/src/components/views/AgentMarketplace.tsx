import React, { useState } from 'react';
import { 
  Bot, Search, Star, Zap, Play, Pause, Settings, Filter,
  Briefcase, Code, Palette, LineChart, Users, Shield,
  Heart, Brain, Megaphone, Scale, Wrench, ChevronRight,
  Sparkles, Clock, TrendingUp
} from 'lucide-react';

type Domain = 'all' | 'finance' | 'tech' | 'creative' | 'analytics' | 'hr' | 'security' | 'wellness' | 'research' | 'marketing' | 'legal' | 'operations';

interface Agent {
  id: string;
  name: string;
  description: string;
  domain: Domain;
  rating: number;
  usageCount: number;
  isFavorite: boolean;
  isActive: boolean;
  capabilities: string[];
}

interface DomainInfo {
  id: Domain;
  label: string;
  icon: React.ElementType;
  color: string;
  agentCount: number;
}

const AgentMarketplace: React.FC = () => {
  const [activeDomain, setActiveDomain] = useState<Domain>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [swarmMode, setSwarmMode] = useState(false);
  const [selectedAgents, setSelectedAgents] = useState<string[]>([]);

  const domains: DomainInfo[] = [
    { id: 'all', label: 'All Agents', icon: Bot, color: 'bg-gradient-to-br from-cyan-400 to-blue-500', agentCount: 144000 },
    { id: 'finance', label: 'Finance', icon: Briefcase, color: 'bg-green-500', agentCount: 15000 },
    { id: 'tech', label: 'Technology', icon: Code, color: 'bg-blue-500', agentCount: 18000 },
    { id: 'creative', label: 'Creative', icon: Palette, color: 'bg-pink-500', agentCount: 12000 },
    { id: 'analytics', label: 'Analytics', icon: LineChart, color: 'bg-purple-500', agentCount: 14000 },
    { id: 'hr', label: 'HR & People', icon: Users, color: 'bg-amber-500', agentCount: 10000 },
    { id: 'security', label: 'Security', icon: Shield, color: 'bg-red-500', agentCount: 8000 },
    { id: 'wellness', label: 'Wellness', icon: Heart, color: 'bg-rose-500', agentCount: 9000 },
    { id: 'research', label: 'Research', icon: Brain, color: 'bg-indigo-500', agentCount: 16000 },
    { id: 'marketing', label: 'Marketing', icon: Megaphone, color: 'bg-orange-500', agentCount: 13000 },
    { id: 'legal', label: 'Legal', icon: Scale, color: 'bg-slate-500', agentCount: 7000 },
    { id: 'operations', label: 'Operations', icon: Wrench, color: 'bg-teal-500', agentCount: 22000 },
  ];

  const [agents, setAgents] = useState<Agent[]>([
    { id: '1', name: 'Budget Optimizer', description: 'Analyzes spending patterns and suggests optimizations for maximum savings', domain: 'finance', rating: 4.9, usageCount: 12500, isFavorite: true, isActive: false, capabilities: ['Budget Analysis', 'Savings Recommendations', 'Expense Tracking'] },
    { id: '2', name: 'Code Reviewer', description: 'Reviews code for best practices, security vulnerabilities, and performance issues', domain: 'tech', rating: 4.8, usageCount: 18200, isFavorite: false, isActive: true, capabilities: ['Code Analysis', 'Security Scan', 'Performance Tips'] },
    { id: '3', name: 'Content Creator', description: 'Generates engaging content for social media, blogs, and marketing campaigns', domain: 'creative', rating: 4.7, usageCount: 9800, isFavorite: true, isActive: false, capabilities: ['Copywriting', 'Social Media', 'Blog Posts'] },
    { id: '4', name: 'Data Analyst', description: 'Processes and visualizes complex datasets to extract actionable insights', domain: 'analytics', rating: 4.9, usageCount: 15600, isFavorite: false, isActive: false, capabilities: ['Data Processing', 'Visualization', 'Trend Analysis'] },
    { id: '5', name: 'HR Assistant', description: 'Streamlines recruitment, onboarding, and employee management processes', domain: 'hr', rating: 4.6, usageCount: 7200, isFavorite: false, isActive: false, capabilities: ['Recruitment', 'Onboarding', 'Performance Reviews'] },
    { id: '6', name: 'Security Auditor', description: 'Continuously monitors systems for vulnerabilities and compliance issues', domain: 'security', rating: 4.8, usageCount: 5400, isFavorite: true, isActive: true, capabilities: ['Vulnerability Scan', 'Compliance Check', 'Threat Detection'] },
    { id: '7', name: 'Wellness Coach', description: 'Provides personalized health recommendations and tracks wellness metrics', domain: 'wellness', rating: 4.5, usageCount: 8900, isFavorite: false, isActive: false, capabilities: ['Health Tips', 'Habit Tracking', 'Stress Management'] },
    { id: '8', name: 'Research Assistant', description: 'Conducts comprehensive research and synthesizes findings into reports', domain: 'research', rating: 4.9, usageCount: 11200, isFavorite: true, isActive: false, capabilities: ['Literature Review', 'Data Synthesis', 'Report Generation'] },
    { id: '9', name: 'Marketing Strategist', description: 'Develops data-driven marketing strategies and campaign optimizations', domain: 'marketing', rating: 4.7, usageCount: 10500, isFavorite: false, isActive: false, capabilities: ['Campaign Planning', 'A/B Testing', 'ROI Analysis'] },
    { id: '10', name: 'Legal Advisor', description: 'Reviews contracts and provides guidance on legal compliance', domain: 'legal', rating: 4.6, usageCount: 4200, isFavorite: false, isActive: false, capabilities: ['Contract Review', 'Compliance', 'Risk Assessment'] },
    { id: '11', name: 'Operations Manager', description: 'Optimizes workflows and automates repetitive operational tasks', domain: 'operations', rating: 4.8, usageCount: 13800, isFavorite: true, isActive: false, capabilities: ['Workflow Automation', 'Process Optimization', 'Resource Allocation'] },
    { id: '12', name: 'Tax Specialist', description: 'Calculates taxes, identifies deductions, and ensures compliance across regions', domain: 'finance', rating: 4.9, usageCount: 8700, isFavorite: false, isActive: false, capabilities: ['Tax Calculation', 'Deduction Finder', 'Multi-Region Support'] },
  ]);

  const toggleFavorite = (id: string) => {
    setAgents(agents.map(a => a.id === id ? { ...a, isFavorite: !a.isFavorite } : a));
  };

  const toggleActive = (id: string) => {
    setAgents(agents.map(a => a.id === id ? { ...a, isActive: !a.isActive } : a));
  };

  const toggleSelectAgent = (id: string) => {
    setSelectedAgents(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const deploySwarm = () => {
    if (selectedAgents.length > 0) {
      setAgents(agents.map(a => 
        selectedAgents.includes(a.id) ? { ...a, isActive: true } : a
      ));
      setSelectedAgents([]);
      setSwarmMode(false);
    }
  };

  const filteredAgents = agents.filter(a => {
    if (activeDomain !== 'all' && a.domain !== activeDomain) return false;
    if (searchQuery && !a.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !a.description.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const activeAgentCount = agents.filter(a => a.isActive).length;
  const favoriteAgents = agents.filter(a => a.isFavorite);

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">AI Agent Marketplace</h2>
          <p className="text-sm text-muted-foreground">144,000 agents across 11 domains • {activeAgentCount} active</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSwarmMode(!swarmMode)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all ${
              swarmMode
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white'
                : 'bg-card border border-border hover:bg-muted'
            }`}
          >
            <Zap className="w-4 h-4" />
            Swarm Mode
          </button>
          {swarmMode && selectedAgents.length > 0 && (
            <button
              onClick={deploySwarm}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-green-500 text-white font-medium hover:bg-green-600 transition-colors"
            >
              <Play className="w-4 h-4" />
              Deploy {selectedAgents.length} Agents
            </button>
          )}
        </div>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search agents by name, capability, or domain..."
          className="w-full bg-card border border-border rounded-2xl pl-12 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>

      {/* Domain Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-6">
        {domains.slice(0, 6).map((domain) => {
          const Icon = domain.icon;
          const isActive = activeDomain === domain.id;
          return (
            <button
              key={domain.id}
              onClick={() => setActiveDomain(domain.id)}
              className={`p-4 rounded-2xl border transition-all ${
                isActive
                  ? 'bg-primary/10 border-primary'
                  : 'bg-card border-border hover:border-primary/50'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl ${domain.color} flex items-center justify-center mb-3`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <p className="text-sm font-medium text-foreground text-left">{domain.label}</p>
              <p className="text-xs text-muted-foreground text-left">{domain.agentCount.toLocaleString()} agents</p>
            </button>
          );
        })}
      </div>

      {/* More Domains */}
      <div className="flex flex-wrap gap-2 mb-6">
        {domains.slice(6).map((domain) => {
          const Icon = domain.icon;
          const isActive = activeDomain === domain.id;
          return (
            <button
              key={domain.id}
              onClick={() => setActiveDomain(domain.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl transition-all ${
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-card border border-border hover:bg-muted'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-sm">{domain.label}</span>
            </button>
          );
        })}
      </div>

      {/* Agents Grid */}
      <div className="flex-1 overflow-y-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAgents.map((agent) => {
            const domainInfo = domains.find(d => d.id === agent.domain);
            const DomainIcon = domainInfo?.icon || Bot;
            const isSelected = selectedAgents.includes(agent.id);

            return (
              <div
                key={agent.id}
                className={`bg-card rounded-2xl border p-5 transition-all ${
                  isSelected ? 'border-primary ring-2 ring-primary/20' : 'border-border hover:border-primary/50'
                } ${swarmMode ? 'cursor-pointer' : ''}`}
                onClick={() => swarmMode && toggleSelectAgent(agent.id)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-xl ${domainInfo?.color} flex items-center justify-center`}>
                      <DomainIcon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{agent.name}</h4>
                      <div className="flex items-center gap-2 mt-0.5">
                        <div className="flex items-center gap-0.5">
                          <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                          <span className="text-xs text-muted-foreground">{agent.rating}</span>
                        </div>
                        <span className="text-xs text-muted-foreground">•</span>
                        <span className="text-xs text-muted-foreground">{agent.usageCount.toLocaleString()} uses</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); toggleFavorite(agent.id); }}
                    className="p-1.5 rounded-lg hover:bg-muted transition-colors"
                  >
                    <Star className={`w-4 h-4 ${agent.isFavorite ? 'text-amber-500 fill-amber-500' : 'text-muted-foreground'}`} />
                  </button>
                </div>

                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{agent.description}</p>

                {/* Capabilities */}
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {agent.capabilities.map((cap) => (
                    <span key={cap} className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                      {cap}
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => { e.stopPropagation(); toggleActive(agent.id); }}
                    className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-xl font-medium transition-all ${
                      agent.isActive
                        ? 'bg-green-500 text-white'
                        : 'bg-primary text-primary-foreground hover:bg-primary/90'
                    }`}
                  >
                    {agent.isActive ? (
                      <>
                        <Pause className="w-4 h-4" />
                        Running
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4" />
                        Deploy
                      </>
                    )}
                  </button>
                  <button className="p-2 rounded-xl bg-muted hover:bg-muted/80 transition-colors">
                    <Settings className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default AgentMarketplace;
