import React from 'react';
import { 
  Users, FolderKanban, MessageSquare, FileText, TrendingUp,
  Clock, CheckCircle2, AlertCircle, Calendar, Activity
} from 'lucide-react';

const GroupDashboard: React.FC = () => {
  const teamStats = [
    { label: 'Team Members', value: '12', icon: Users, color: 'bg-blue-500' },
    { label: 'Active Projects', value: '8', icon: FolderKanban, color: 'bg-green-500' },
    { label: 'Messages Today', value: '47', icon: MessageSquare, color: 'bg-purple-500' },
    { label: 'Files Shared', value: '156', icon: FileText, color: 'bg-amber-500' },
  ];

  const recentActivity = [
    { id: '1', user: 'Sarah Johnson', action: 'completed task', target: 'Design review', time: '5 min ago', avatar: 'SJ' },
    { id: '2', user: 'Mike Chen', action: 'uploaded file', target: 'Q4 Report.pdf', time: '15 min ago', avatar: 'MC' },
    { id: '3', user: 'David Park', action: 'commented on', target: 'Marketing strategy', time: '1 hr ago', avatar: 'DP' },
    { id: '4', user: 'Emily Rodriguez', action: 'created workspace', target: 'Product Launch', time: '2 hrs ago', avatar: 'ER' },
    { id: '5', user: 'Alex Kim', action: 'joined team', target: 'Engineering', time: '3 hrs ago', avatar: 'AK' },
  ];

  const upcomingMeetings = [
    { id: '1', title: 'Team Standup', time: '10:00 AM', attendees: 8, isNow: true },
    { id: '2', title: 'Project Review', time: '2:00 PM', attendees: 5, isNow: false },
    { id: '3', title: 'Sprint Planning', time: '4:00 PM', attendees: 12, isNow: false },
  ];

  const projectProgress = [
    { name: 'Q4 Marketing Campaign', progress: 75, status: 'on-track', dueDate: 'Dec 15' },
    { name: 'Product Roadmap 2026', progress: 45, status: 'on-track', dueDate: 'Jan 30' },
    { name: 'Website Redesign', progress: 90, status: 'ahead', dueDate: 'Nov 30' },
    { name: 'Mobile App Launch', progress: 30, status: 'at-risk', dueDate: 'Feb 15' },
  ];

  const statusColors = {
    'on-track': 'text-green-500 bg-green-500/10',
    'ahead': 'text-blue-500 bg-blue-500/10',
    'at-risk': 'text-red-500 bg-red-500/10',
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-foreground">Team Dashboard</h2>
        <p className="text-sm text-muted-foreground">Overview of your team's activity and progress</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {teamStats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-card rounded-2xl border border-border p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-muted-foreground">{stat.label}</span>
                <div className={`w-8 h-8 rounded-lg ${stat.color} flex items-center justify-center`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
              </div>
              <p className="metric-value text-foreground">{stat.value}</p>
            </div>
          );
        })}
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0">
        {/* Recent Activity */}
        <div className="lg:col-span-1 bg-card rounded-2xl border border-border p-5 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">Recent Activity</h3>
            <Activity className="w-5 h-5 text-muted-foreground" />
          </div>
          <div className="flex-1 overflow-y-auto space-y-4">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white text-xs font-medium flex-shrink-0">
                  {activity.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground">
                    <span className="font-medium">{activity.user}</span>{' '}
                    <span className="text-muted-foreground">{activity.action}</span>{' '}
                    <span className="font-medium">{activity.target}</span>
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Project Progress */}
        <div className="lg:col-span-1 bg-card rounded-2xl border border-border p-5 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">Project Progress</h3>
            <TrendingUp className="w-5 h-5 text-muted-foreground" />
          </div>
          <div className="flex-1 overflow-y-auto space-y-4">
            {projectProgress.map((project) => (
              <div key={project.name}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-foreground truncate">{project.name}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${statusColors[project.status]}`}>
                    {project.status.replace('-', ' ')}
                  </span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden mb-1">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      project.status === 'at-risk' ? 'bg-red-500' :
                      project.status === 'ahead' ? 'bg-blue-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${project.progress}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{project.progress}% complete</span>
                  <span>Due {project.dueDate}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Meetings */}
        <div className="lg:col-span-1 bg-card rounded-2xl border border-border p-5 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">Upcoming Meetings</h3>
            <Calendar className="w-5 h-5 text-muted-foreground" />
          </div>
          <div className="flex-1 overflow-y-auto space-y-3">
            {upcomingMeetings.map((meeting) => (
              <div
                key={meeting.id}
                className={`p-3 rounded-xl transition-colors ${
                  meeting.isNow ? 'bg-primary/10 border border-primary' : 'bg-muted/50'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium text-foreground">{meeting.title}</h4>
                  {meeting.isNow && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-primary text-primary-foreground animate-pulse">
                      Now
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{meeting.time}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    <span>{meeting.attendees} attendees</span>
                  </div>
                </div>
                {meeting.isNow && (
                  <button className="w-full mt-3 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
                    Join Meeting
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GroupDashboard;
