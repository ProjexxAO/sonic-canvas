import React, { useState } from 'react';
import { 
  Wallet, TrendingUp, TrendingDown, CreditCard, Building2, 
  PiggyBank, Receipt, ArrowUpRight, ArrowDownRight, Filter,
  Calendar, Globe, ChevronDown, MoreHorizontal, RefreshCw
} from 'lucide-react';

type TaxRegion = 'AU' | 'UK' | 'US';

interface Transaction {
  id: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  date: string;
  account: string;
}

interface Account {
  id: string;
  name: string;
  type: 'checking' | 'savings' | 'credit' | 'investment';
  balance: number;
  institution: string;
  lastSync: string;
}

const FinanceDashboard: React.FC = () => {
  const [taxRegion, setTaxRegion] = useState<TaxRegion>('US');
  const [showRegionDropdown, setShowRegionDropdown] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState('30d');

  const accounts: Account[] = [
    { id: '1', name: 'Main Checking', type: 'checking', balance: 12450.82, institution: 'Chase Bank', lastSync: '2 min ago' },
    { id: '2', name: 'Savings Account', type: 'savings', balance: 45200.00, institution: 'Ally Bank', lastSync: '5 min ago' },
    { id: '3', name: 'Credit Card', type: 'credit', balance: -2340.50, institution: 'Amex', lastSync: '10 min ago' },
    { id: '4', name: 'Investment Portfolio', type: 'investment', balance: 128750.00, institution: 'Fidelity', lastSync: '1 hr ago' },
  ];

  const transactions: Transaction[] = [
    { id: '1', description: 'Salary Deposit', amount: 8500, type: 'income', category: 'Income', date: 'Jan 24', account: 'Main Checking' },
    { id: '2', description: 'Rent Payment', amount: 2200, type: 'expense', category: 'Housing', date: 'Jan 23', account: 'Main Checking' },
    { id: '3', description: 'Grocery Store', amount: 156.42, type: 'expense', category: 'Food', date: 'Jan 23', account: 'Credit Card' },
    { id: '4', description: 'Netflix', amount: 15.99, type: 'expense', category: 'Entertainment', date: 'Jan 22', account: 'Credit Card' },
    { id: '5', description: 'Freelance Payment', amount: 1200, type: 'income', category: 'Income', date: 'Jan 22', account: 'Main Checking' },
    { id: '6', description: 'Electric Bill', amount: 145.00, type: 'expense', category: 'Utilities', date: 'Jan 21', account: 'Main Checking' },
    { id: '7', description: 'Gas Station', amount: 52.30, type: 'expense', category: 'Transportation', date: 'Jan 21', account: 'Credit Card' },
    { id: '8', description: 'Restaurant', amount: 78.50, type: 'expense', category: 'Food', date: 'Jan 20', account: 'Credit Card' },
    { id: '9', description: 'Gym Membership', amount: 49.99, type: 'expense', category: 'Health', date: 'Jan 20', account: 'Credit Card' },
    { id: '10', description: 'Amazon Purchase', amount: 234.99, type: 'expense', category: 'Shopping', date: 'Jan 19', account: 'Credit Card' },
    { id: '11', description: 'Dividend Payment', amount: 125.00, type: 'income', category: 'Investment', date: 'Jan 19', account: 'Investment Portfolio' },
    { id: '12', description: 'Internet Bill', amount: 79.99, type: 'expense', category: 'Utilities', date: 'Jan 18', account: 'Main Checking' },
  ];

  const spendingByCategory = [
    { category: 'Housing', amount: 2200, percentage: 45, color: 'bg-blue-500' },
    { category: 'Food', amount: 450, percentage: 18, color: 'bg-green-500' },
    { category: 'Transportation', amount: 280, percentage: 12, color: 'bg-amber-500' },
    { category: 'Utilities', amount: 225, percentage: 10, color: 'bg-purple-500' },
    { category: 'Entertainment', amount: 180, percentage: 8, color: 'bg-pink-500' },
    { category: 'Shopping', amount: 350, percentage: 7, color: 'bg-cyan-500' },
  ];

  const taxRegions = [
    { id: 'US' as TaxRegion, label: 'United States', flag: '🇺🇸', currency: 'USD' },
    { id: 'UK' as TaxRegion, label: 'United Kingdom', flag: '🇬🇧', currency: 'GBP' },
    { id: 'AU' as TaxRegion, label: 'Australia', flag: '🇦🇺', currency: 'AUD' },
  ];

  const totalBalance = accounts.reduce((acc, a) => acc + a.balance, 0);
  const monthlyIncome = transactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
  const monthlyExpenses = transactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);
  const cashFlow = monthlyIncome - monthlyExpenses;

  const currentRegion = taxRegions.find(r => r.id === taxRegion);

  // Cash flow chart data (30 days)
  const cashFlowData = Array.from({ length: 30 }, (_, i) => ({
    day: i + 1,
    income: Math.random() * 500 + 200,
    expense: Math.random() * 400 + 100,
  }));

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Financial Dashboard</h2>
          <p className="text-sm text-muted-foreground">Connected via Plaid • Last sync: 2 min ago</p>
        </div>
        <div className="flex items-center gap-3">
          {/* Tax Region Selector */}
          <div className="relative">
            <button
              onClick={() => setShowRegionDropdown(!showRegionDropdown)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-card border border-border hover:bg-muted transition-colors"
            >
              <Globe className="w-4 h-4" />
              <span className="text-sm">{currentRegion?.flag} {currentRegion?.id}</span>
              <ChevronDown className="w-4 h-4" />
            </button>
            {showRegionDropdown && (
              <div className="absolute right-0 top-full mt-2 w-48 bg-card border border-border rounded-xl shadow-xl z-10">
                {taxRegions.map((region) => (
                  <button
                    key={region.id}
                    onClick={() => { setTaxRegion(region.id); setShowRegionDropdown(false); }}
                    className={`w-full flex items-center gap-2 px-4 py-2.5 hover:bg-muted transition-colors first:rounded-t-xl last:rounded-b-xl ${
                      taxRegion === region.id ? 'bg-primary/10' : ''
                    }`}
                  >
                    <span>{region.flag}</span>
                    <span className="text-sm">{region.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors">
            <RefreshCw className="w-4 h-4" />
            Sync Accounts
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-muted-foreground">Total Balance</span>
            <Wallet className="w-5 h-5 text-primary" />
          </div>
          <p className="metric-value text-foreground">${totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
          <div className="flex items-center gap-1 mt-1 text-green-500">
            <TrendingUp className="w-4 h-4" />
            <span className="text-sm">+8.2% this month</span>
          </div>
        </div>

        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-muted-foreground">Monthly Income</span>
            <ArrowUpRight className="w-5 h-5 text-green-500" />
          </div>
          <p className="metric-value text-green-500">+${monthlyIncome.toLocaleString()}</p>
          <p className="text-xs text-muted-foreground mt-1">From 3 sources</p>
        </div>

        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-muted-foreground">Monthly Expenses</span>
            <ArrowDownRight className="w-5 h-5 text-red-500" />
          </div>
          <p className="metric-value text-foreground">-${monthlyExpenses.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
          <p className="text-xs text-muted-foreground mt-1">12% under budget</p>
        </div>

        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-muted-foreground">Cash Flow</span>
            <TrendingUp className="w-5 h-5 text-cyan-500" />
          </div>
          <p className={`metric-value ${cashFlow >= 0 ? 'text-green-500' : 'text-red-500'}`}>
            {cashFlow >= 0 ? '+' : ''}${cashFlow.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </p>
          <p className="text-xs text-muted-foreground mt-1">Projected savings</p>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0">
        {/* Accounts & Transactions */}
        <div className="lg:col-span-2 flex flex-col gap-6 min-h-0">
          {/* Connected Accounts */}
          <div className="bg-card rounded-2xl border border-border p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">Connected Accounts</h3>
              <button className="text-sm text-primary hover:underline">+ Add Account</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {accounts.map((account) => (
                <div key={account.id} className="flex items-center gap-3 p-3 rounded-xl bg-muted/50 hover:bg-muted transition-colors">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    account.type === 'checking' ? 'bg-blue-500' :
                    account.type === 'savings' ? 'bg-green-500' :
                    account.type === 'credit' ? 'bg-red-500' : 'bg-purple-500'
                  }`}>
                    {account.type === 'checking' && <Building2 className="w-5 h-5 text-white" />}
                    {account.type === 'savings' && <PiggyBank className="w-5 h-5 text-white" />}
                    {account.type === 'credit' && <CreditCard className="w-5 h-5 text-white" />}
                    {account.type === 'investment' && <TrendingUp className="w-5 h-5 text-white" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{account.name}</p>
                    <p className="text-xs text-muted-foreground">{account.institution}</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-semibold ${account.balance < 0 ? 'text-red-500' : 'text-foreground'}`}>
                      ${Math.abs(account.balance).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </p>
                    <p className="text-[10px] text-muted-foreground">{account.lastSync}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Transactions */}
          <div className="flex-1 bg-card rounded-2xl border border-border p-5 flex flex-col min-h-0">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">Recent Transactions</h3>
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-muted hover:bg-muted/80 text-sm">
                  <Filter className="w-3 h-3" />
                  Filter
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto space-y-2">
              {transactions.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      tx.type === 'income' ? 'bg-green-500/10' : 'bg-muted'
                    }`}>
                      {tx.type === 'income' ? (
                        <ArrowUpRight className="w-4 h-4 text-green-500" />
                      ) : (
                        <ArrowDownRight className="w-4 h-4 text-muted-foreground" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm text-foreground">{tx.description}</p>
                      <p className="text-xs text-muted-foreground">{tx.category} • {tx.account}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${tx.type === 'income' ? 'text-green-500' : 'text-foreground'}`}>
                      {tx.type === 'income' ? '+' : '-'}${tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-muted-foreground">{tx.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Spending Breakdown & Cash Flow */}
        <div className="flex flex-col gap-6">
          {/* Spending by Category */}
          <div className="bg-card rounded-2xl border border-border p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">Spending by Category</h3>
              <Receipt className="w-5 h-5 text-muted-foreground" />
            </div>
            <div className="space-y-3">
              {spendingByCategory.map((cat) => (
                <div key={cat.category}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-foreground">{cat.category}</span>
                    <span className="text-sm font-medium text-foreground">${cat.amount}</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full ${cat.color} rounded-full transition-all duration-500`}
                      style={{ width: `${cat.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cash Flow Chart */}
          <div className="flex-1 bg-card rounded-2xl border border-border p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">30-Day Cash Flow</h3>
              <div className="flex gap-2">
                {['7d', '30d', '90d'].map((period) => (
                  <button
                    key={period}
                    onClick={() => setSelectedPeriod(period)}
                    className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                      selectedPeriod === period ? 'bg-primary text-primary-foreground' : 'bg-muted hover:bg-muted/80'
                    }`}
                  >
                    {period}
                  </button>
                ))}
              </div>
            </div>
            {/* Simple bar chart visualization */}
            <div className="h-40 flex items-end gap-0.5">
              {cashFlowData.slice(0, 30).map((day, i) => {
                const netFlow = day.income - day.expense;
                const height = Math.abs(netFlow) / 5;
                return (
                  <div
                    key={i}
                    className={`flex-1 rounded-t transition-all hover:opacity-80 ${
                      netFlow >= 0 ? 'bg-green-500' : 'bg-red-500'
                    }`}
                    style={{ height: `${Math.min(height, 100)}%` }}
                    title={`Day ${day.day}: ${netFlow >= 0 ? '+' : ''}$${netFlow.toFixed(0)}`}
                  />
                );
              })}
            </div>
            <div className="flex items-center justify-between mt-3 text-xs text-muted-foreground">
              <span>30 days ago</span>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                  <span>Positive</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-red-500" />
                  <span>Negative</span>
                </div>
              </div>
              <span>Today</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinanceDashboard;
