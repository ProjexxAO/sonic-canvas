import React, { useState, useEffect } from 'react';
import { 
  Heart, Brain, Moon, Activity, Zap, Timer, Play, Pause, 
  RotateCcw, Settings, TrendingUp, Calendar, Target,
  Sparkles, Volume2, VolumeX, Coffee
} from 'lucide-react';

const WellnessView: React.FC = () => {
  const [focusTime, setFocusTime] = useState(25 * 60); // 25 minutes in seconds
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [adhdMode, setAdhdMode] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [sessionsCompleted, setSessionsCompleted] = useState(3);

  // Focus timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && focusTime > 0) {
      interval = setInterval(() => {
        setFocusTime(prev => prev - 1);
      }, 1000);
    } else if (focusTime === 0) {
      setIsTimerRunning(false);
      setSessionsCompleted(prev => prev + 1);
      setFocusTime(25 * 60);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, focusTime]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const toggleTimer = () => setIsTimerRunning(!isTimerRunning);
  const resetTimer = () => {
    setIsTimerRunning(false);
    setFocusTime(25 * 60);
  };

  const wellnessMetrics = [
    { label: 'Stress Level', value: 'Low', score: 25, color: 'bg-green-500', icon: Brain },
    { label: 'Energy', value: 'High', score: 82, color: 'bg-amber-500', icon: Zap },
    { label: 'Sleep Quality', value: '7.2 hrs', score: 72, color: 'bg-indigo-500', icon: Moon },
    { label: 'Activity', value: '6,500 steps', score: 65, color: 'bg-cyan-500', icon: Activity },
  ];

  const dailyNudges = [
    { id: '1', message: 'Time for a 5-minute stretch break!', type: 'movement', time: '10:00 AM' },
    { id: '2', message: 'Stay hydrated - drink some water', type: 'hydration', time: '11:30 AM' },
    { id: '3', message: 'Great focus session! Take a short walk', type: 'break', time: '2:00 PM' },
    { id: '4', message: 'Wind down - start your evening routine', type: 'routine', time: '8:00 PM' },
  ];

  const lifeBalanceAreas = [
    { area: 'Work', score: 75, target: 80 },
    { area: 'Health', score: 82, target: 85 },
    { area: 'Relationships', score: 68, target: 75 },
    { area: 'Personal Growth', score: 70, target: 80 },
    { area: 'Recreation', score: 55, target: 70 },
    { area: 'Finance', score: 78, target: 80 },
  ];

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Wellness & Productivity</h2>
          <p className="text-sm text-muted-foreground">Your daily wellness score: 78/100</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setAdhdMode(!adhdMode)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all ${
              adhdMode
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                : 'bg-card border border-border hover:bg-muted'
            }`}
          >
            <Brain className="w-4 h-4" />
            ADHD Mode {adhdMode ? 'ON' : 'OFF'}
          </button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0">
        {/* Focus Timer */}
        <div className="lg:col-span-1">
          <div className="bg-card rounded-2xl border border-border p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-semibold text-foreground">Focus Timer</h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSoundEnabled(!soundEnabled)}
                  className="p-2 rounded-lg hover:bg-muted transition-colors"
                >
                  {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </button>
                <button className="p-2 rounded-lg hover:bg-muted transition-colors">
                  <Settings className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Timer Display */}
            <div className="relative w-48 h-48 mx-auto mb-6">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="96"
                  cy="96"
                  r="88"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="8"
                  className="text-muted"
                />
                <circle
                  cx="96"
                  cy="96"
                  r="88"
                  fill="none"
                  stroke="url(#timerGradient)"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${(focusTime / (25 * 60)) * 553} 553`}
                  className="transition-all duration-1000"
                />
                <defs>
                  <linearGradient id="timerGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#a855f7" />
                    <stop offset="100%" stopColor="#ec4899" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-bold text-foreground font-mono">{formatTime(focusTime)}</span>
                <span className="text-sm text-muted-foreground">
                  {isTimerRunning ? 'Focus time' : 'Ready to focus'}
                </span>
              </div>
            </div>

            {/* Timer Controls */}
            <div className="flex items-center justify-center gap-4 mb-6">
              <button
                onClick={resetTimer}
                className="w-12 h-12 rounded-full bg-muted hover:bg-muted/80 flex items-center justify-center transition-colors"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
              <button
                onClick={toggleTimer}
                className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
                  isTimerRunning
                    ? 'bg-red-500 hover:bg-red-600'
                    : 'bg-gradient-to-r from-purple-500 to-pink-500 hover:opacity-90'
                } text-white`}
              >
                {isTimerRunning ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
              </button>
              <button className="w-12 h-12 rounded-full bg-muted hover:bg-muted/80 flex items-center justify-center transition-colors">
                <Coffee className="w-5 h-5" />
              </button>
            </div>

            {/* Session Stats */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-muted/50">
              <div className="text-center">
                <p className="text-2xl font-bold text-foreground">{sessionsCompleted}</p>
                <p className="text-xs text-muted-foreground">Sessions today</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-foreground">{sessionsCompleted * 25}</p>
                <p className="text-xs text-muted-foreground">Minutes focused</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-foreground">5</p>
                <p className="text-xs text-muted-foreground">Day streak</p>
              </div>
            </div>

            {/* ADHD Mode Info */}
            {adhdMode && (
              <div className="mt-4 p-3 rounded-xl bg-purple-500/10 border border-purple-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <Sparkles className="w-4 h-4 text-purple-500" />
                  <span className="text-sm font-medium text-purple-500">ADHD Support Active</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Distractions blocked • Micro-breaks enabled • Gentle reminders on
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Wellness Metrics & Life Balance */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          {/* Wellness Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {wellnessMetrics.map((metric) => {
              const Icon = metric.icon;
              return (
                <div key={metric.label} className="bg-card rounded-2xl border border-border p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <div className={`w-8 h-8 rounded-lg ${metric.color} flex items-center justify-center`}>
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-xs text-muted-foreground">{metric.label}</span>
                  </div>
                  <p className="text-lg font-semibold text-foreground mb-2">{metric.value}</p>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full ${metric.color} rounded-full transition-all duration-500`}
                      style={{ width: `${metric.score}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Life Balance */}
          <div className="bg-card rounded-2xl border border-border p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">Life Balance Tracking</h3>
              <Target className="w-5 h-5 text-primary" />
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {lifeBalanceAreas.map((area) => {
                const isOnTrack = area.score >= area.target - 10;
                return (
                  <div key={area.area} className="p-3 rounded-xl bg-muted/50">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-foreground">{area.area}</span>
                      <span className={`text-xs font-medium ${isOnTrack ? 'text-green-500' : 'text-amber-500'}`}>
                        {area.score}%
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden relative">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isOnTrack ? 'bg-green-500' : 'bg-amber-500'
                        }`}
                        style={{ width: `${area.score}%` }}
                      />
                      <div
                        className="absolute top-0 h-full w-0.5 bg-foreground/30"
                        style={{ left: `${area.target}%` }}
                      />
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-1">Target: {area.target}%</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Smart Nudges */}
          <div className="bg-card rounded-2xl border border-border p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">Smart Nudges</h3>
              <span className="text-xs text-muted-foreground">Today's reminders</span>
            </div>
            <div className="space-y-3">
              {dailyNudges.map((nudge, index) => {
                const isPast = index < 2;
                return (
                  <div
                    key={nudge.id}
                    className={`flex items-center gap-3 p-3 rounded-xl transition-colors ${
                      isPast ? 'bg-muted/30 opacity-60' : 'bg-muted/50'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isPast ? 'bg-green-500/20' : 'bg-primary/20'
                    }`}>
                      {isPast ? (
                        <svg className="w-4 h-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      ) : (
                        <Timer className="w-4 h-4 text-primary" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-foreground">{nudge.message}</p>
                      <p className="text-xs text-muted-foreground">{nudge.time}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WellnessView;
