import React, { useState } from 'react';
import { 
  Search, Bell, Settings, Moon, Sun, User, ChevronDown,
  LogOut, HelpCircle, Keyboard, Shield, LogIn
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import AuthModal from '@/components/auth/AuthModal';
import ProfileSettings from '@/components/profile/ProfileSettings';

interface TopHeaderProps {
  activeHub: 'personal' | 'group' | 'enterprise';
  activeView: string;
}

const TopHeader: React.FC<TopHeaderProps> = ({ activeHub, activeView }) => {
  const { user, isAuthenticated, signOut } = useAuth();
  
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showProfileSettings, setShowProfileSettings] = useState(false);

  const notifications = [
    { id: '1', title: 'Budget alert', message: 'You\'ve reached 80% of your monthly budget', time: '5 min ago', type: 'warning' },
    { id: '2', title: 'Task completed', message: 'Team standup meeting marked as done', time: '15 min ago', type: 'success' },
    { id: '3', title: 'New message', message: 'Sarah Johnson mentioned you in #general', time: '1 hr ago', type: 'info' },
  ];

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const handleSignOut = async () => {
    await signOut();
    setShowUserMenu(false);
  };

  const handleOpenProfile = () => {
    setShowUserMenu(false);
    setShowProfileSettings(true);
  };

  const getViewTitle = () => {
    const titles: Record<string, string> = {
      dashboard: 'Dashboard',
      inbox: 'Unified Inbox',
      finance: 'Financial Dashboard',
      agents: 'AI Agents',
      collaboration: 'Collaboration',
      wellness: 'Wellness',
      documents: 'Documents',
    };
    return titles[activeView] || 'Dashboard';
  };

  const getHubLabel = () => {
    const labels: Record<string, string> = {
      personal: 'Personal Hub',
      group: 'Group Hub',
      enterprise: 'Enterprise Hub',
    };
    return labels[activeHub];
  };

  const getUserInitials = () => {
    if (user?.fullName) {
      return user.fullName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    }
    if (user?.email) {
      return user.email[0].toUpperCase();
    }
    return 'U';
  };

  return (
    <>
      <header className="h-16 bg-card/50 backdrop-blur-lg border-b border-border flex items-center justify-between px-6 sticky top-0 z-30">
        {/* Left - Breadcrumb */}
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">{getHubLabel()}</span>
          <span className="text-muted-foreground">/</span>
          <span className="text-sm font-medium text-foreground">{getViewTitle()}</span>
        </div>

        {/* Center - Search */}
        <div className="flex-1 max-w-xl mx-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search anything... (⌘K)"
              className="w-full bg-muted/50 border border-border rounded-xl pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:bg-card transition-all"
            />
            <kbd className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground border border-border">
              ⌘K
            </kbd>
          </div>
        </div>

        {/* Right - Actions */}
        <div className="flex items-center gap-2">
          {/* Dark Mode Toggle */}
          <button
            onClick={toggleDarkMode}
            className="w-9 h-9 rounded-xl bg-muted/50 hover:bg-muted flex items-center justify-center transition-colors"
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {isAuthenticated ? (
            <>
              {/* Notifications */}
              <div className="relative">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="w-9 h-9 rounded-xl bg-muted/50 hover:bg-muted flex items-center justify-center transition-colors relative"
                >
                  <Bell className="w-4 h-4" />
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center">
                    3
                  </span>
                </button>

                {showNotifications && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setShowNotifications(false)} />
                    <div className="absolute right-0 top-full mt-2 w-80 bg-card border border-border rounded-2xl shadow-xl z-50 overflow-hidden">
                      <div className="p-4 border-b border-border">
                        <h3 className="font-semibold text-foreground">Notifications</h3>
                      </div>
                      <div className="max-h-80 overflow-y-auto">
                        {notifications.map((notif) => (
                          <div key={notif.id} className="p-4 hover:bg-muted/50 transition-colors border-b border-border last:border-0">
                            <div className="flex items-start gap-3">
                              <div className={`w-2 h-2 rounded-full mt-2 ${
                                notif.type === 'warning' ? 'bg-amber-500' :
                                notif.type === 'success' ? 'bg-green-500' : 'bg-blue-500'
                              }`} />
                              <div className="flex-1">
                                <p className="text-sm font-medium text-foreground">{notif.title}</p>
                                <p className="text-xs text-muted-foreground mt-0.5">{notif.message}</p>
                                <p className="text-[10px] text-muted-foreground mt-1">{notif.time}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="p-3 border-t border-border">
                        <button className="w-full text-sm text-primary hover:underline">
                          View all notifications
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Settings */}
              <button 
                onClick={() => setShowProfileSettings(true)}
                className="w-9 h-9 rounded-xl bg-muted/50 hover:bg-muted flex items-center justify-center transition-colors"
              >
                <Settings className="w-4 h-4" />
              </button>

              {/* User Menu */}
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-2 px-2 py-1.5 rounded-xl hover:bg-muted transition-colors"
                >
                  {user?.avatarUrl ? (
                    <img 
                      src={user.avatarUrl} 
                      alt={user.fullName || 'User'} 
                      className="w-8 h-8 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white text-sm font-medium">
                      {getUserInitials()}
                    </div>
                  )}
                  <ChevronDown className="w-4 h-4 text-muted-foreground" />
                </button>

                {showUserMenu && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setShowUserMenu(false)} />
                    <div className="absolute right-0 top-full mt-2 w-56 bg-card border border-border rounded-2xl shadow-xl z-50 overflow-hidden">
                      <div className="p-4 border-b border-border">
                        <p className="font-medium text-foreground">{user?.fullName || 'User'}</p>
                        <p className="text-xs text-muted-foreground">{user?.email}</p>
                      </div>
                      <div className="py-2">
                        <button 
                          onClick={handleOpenProfile}
                          className="w-full flex items-center gap-3 px-4 py-2 hover:bg-muted transition-colors"
                        >
                          <User className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">Profile</span>
                        </button>
                        <button 
                          onClick={handleOpenProfile}
                          className="w-full flex items-center gap-3 px-4 py-2 hover:bg-muted transition-colors"
                        >
                          <Shield className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">Privacy & Security</span>
                        </button>
                        <button className="w-full flex items-center gap-3 px-4 py-2 hover:bg-muted transition-colors">
                          <Keyboard className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">Keyboard Shortcuts</span>
                        </button>
                        <button className="w-full flex items-center gap-3 px-4 py-2 hover:bg-muted transition-colors">
                          <HelpCircle className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">Help & Support</span>
                        </button>
                      </div>
                      <div className="py-2 border-t border-border">
                        <button 
                          onClick={handleSignOut}
                          className="w-full flex items-center gap-3 px-4 py-2 hover:bg-muted transition-colors text-red-500"
                        >
                          <LogOut className="w-4 h-4" />
                          <span className="text-sm">Sign Out</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </>
          ) : (
            <>
              {/* Sign In Button */}
              <button
                onClick={() => setShowAuthModal(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
              >
                <LogIn className="w-4 h-4" />
                <span className="text-sm">Sign In</span>
              </button>
            </>
          )}
        </div>
      </header>

      {/* Auth Modal */}
      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
      />

      {/* Profile Settings Modal */}
      <ProfileSettings
        isOpen={showProfileSettings}
        onClose={() => setShowProfileSettings(false)}
      />
    </>
  );
};

export default TopHeader;
