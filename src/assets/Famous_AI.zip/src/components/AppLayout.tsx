import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { useIsMobile } from '@/hooks/use-mobile';
import MainSidebar, { HubType, ViewType } from './sidebar/MainSidebar';
import TopHeader from './header/TopHeader';
import AtlasOrb from './atlas/AtlasOrb';
import PersonalDashboard from './views/PersonalDashboard';
import GroupDashboard from './views/GroupDashboard';
import EnterpriseDashboard from './views/EnterpriseDashboard';
import UnifiedInbox from './views/UnifiedInbox';
import FinanceDashboard from './views/FinanceDashboard';
import AgentMarketplace from './views/AgentMarketplace';
import CollaborationWorkspace from './views/CollaborationWorkspace';
import WellnessView from './views/WellnessView';

const AppLayout: React.FC = () => {
  const { sidebarOpen, toggleSidebar } = useAppContext();
  const { preferences, isLoading } = useAuth();
  const isMobile = useIsMobile();
  const [activeHub, setActiveHub] = useState<HubType>('personal');
  const [activeView, setActiveView] = useState<ViewType>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Apply theme from preferences
  useEffect(() => {
    if (preferences?.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else if (preferences?.theme === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      // Default to dark mode
      document.documentElement.classList.add('dark');
    }
  }, [preferences?.theme]);

  // Set default hub from preferences
  useEffect(() => {
    if (preferences?.defaultHub) {
      setActiveHub(preferences.defaultHub as HubType);
    }
  }, [preferences?.defaultHub]);

  const handleHubChange = (hub: HubType) => {
    setActiveHub(hub);
    setActiveView('dashboard');
  };

  const handleViewChange = (view: ViewType) => {
    setActiveView(view);
  };

  const handleAtlasCommand = (command: string) => {
    // Handle Atlas voice commands
    const lowerCommand = command.toLowerCase();
    if (lowerCommand.includes('inbox')) {
      setActiveView('inbox');
    } else if (lowerCommand.includes('finance')) {
      setActiveView('finance');
    } else if (lowerCommand.includes('agent')) {
      setActiveView('agents');
    } else if (lowerCommand.includes('wellness')) {
      setActiveView('wellness');
    } else if (lowerCommand.includes('collaboration') || lowerCommand.includes('team')) {
      setActiveView('collaboration');
    } else if (lowerCommand.includes('personal')) {
      setActiveHub('personal');
    } else if (lowerCommand.includes('group')) {
      setActiveHub('group');
    } else if (lowerCommand.includes('enterprise')) {
      setActiveHub('enterprise');
    }
  };

  const renderContent = () => {
    // Personal Hub Views
    if (activeHub === 'personal') {
      switch (activeView) {
        case 'dashboard':
          return <PersonalDashboard />;
        case 'inbox':
          return <UnifiedInbox />;
        case 'finance':
          return <FinanceDashboard />;
        case 'agents':
          return <AgentMarketplace />;
        case 'wellness':
          return <WellnessView />;
        case 'collaboration':
          return <CollaborationWorkspace />;
        default:
          return <PersonalDashboard />;
      }
    }

    // Group Hub Views
    if (activeHub === 'group') {
      switch (activeView) {
        case 'dashboard':
          return <GroupDashboard />;
        case 'collaboration':
          return <CollaborationWorkspace />;
        case 'inbox':
          return <UnifiedInbox />;
        default:
          return <GroupDashboard />;
      }
    }

    // Enterprise Hub Views
    if (activeHub === 'enterprise') {
      switch (activeView) {
        case 'dashboard':
          return <EnterpriseDashboard />;
        case 'finance':
          return <FinanceDashboard />;
        case 'agents':
          return <AgentMarketplace />;
        case 'collaboration':
          return <CollaborationWorkspace />;
        default:
          return <EnterpriseDashboard />;
      }
    }

    return <PersonalDashboard />;
  };

  // Show loading state while checking auth
  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 animate-pulse flex items-center justify-center">
            <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
            </svg>
          </div>
          <p className="text-muted-foreground">Loading Atlas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <MainSidebar
        activeHub={activeHub}
        activeView={activeView}
        onHubChange={handleHubChange}
        onViewChange={handleViewChange}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main Content */}
      <div
        className={`transition-all duration-300 ${
          sidebarCollapsed ? 'ml-20' : 'ml-64'
        }`}
      >
        {/* Top Header */}
        <TopHeader activeHub={activeHub} activeView={activeView} />

        {/* Page Content */}
        <main className="p-6 min-h-[calc(100vh-4rem)]">
          {renderContent()}
        </main>
      </div>

      {/* Atlas Voice Assistant */}
      <AtlasOrb onCommand={handleAtlasCommand} />
    </div>
  );
};

export default AppLayout;
