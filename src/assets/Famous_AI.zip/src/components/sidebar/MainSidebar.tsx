import React from 'react';
import {
  Home,
  Users,
  Building2,
  Inbox,
  Wallet,
  Bot,
  FolderKanban,
  Settings,
  Bell,
  Search,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Heart,
  FileText,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

export type HubType = 'personal' | 'group' | 'enterprise';
export type ViewType = 'dashboard' | 'inbox' | 'finance' | 'agents' | 'collaboration' | 'wellness' | 'documents';

interface MainSidebarProps {
  activeHub: HubType;
  activeView: ViewType;
  onHubChange: (hub: HubType) => void;
  onViewChange: (view: ViewType) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

const MainSidebar: React.FC<MainSidebarProps> = ({
  activeHub,
  activeView,
  onHubChange,
  onViewChange,
  collapsed,
  onToggleCollapse,
}) => {
  const { user, isAuthenticated } = useAuth();

  const hubs = [
    { id: 'personal' as HubType, label: 'Personal', icon: Home, color: 'from-cyan-400 to-blue-500' },
    { id: 'group' as HubType, label: 'Group', icon: Users, color: 'from-green-400 to-emerald-500' },
    { id: 'enterprise' as HubType, label: 'Enterprise', icon: Building2, color: 'from-purple-400 to-pink-500' },
  ];

  const personalViews = [
    { id: 'dashboard' as ViewType, label: 'Dashboard', icon: Home },
    { id: 'inbox' as ViewType, label: 'Unified Inbox', icon: Inbox },
    { id: 'finance' as ViewType, label: 'Finances', icon: Wallet },
    { id: 'agents' as ViewType, label: 'AI Agents', icon: Bot },
    { id: 'wellness' as ViewType, label: 'Wellness', icon: Heart },
    { id: 'documents' as ViewType, label: 'Documents', icon: FileText },
  ];

  const groupViews = [
    { id: 'dashboard' as ViewType, label: 'Team Dashboard', icon: Home },
    { id: 'collaboration' as ViewType, label: 'Workspaces', icon: FolderKanban },
    { id: 'inbox' as ViewType, label: 'Team Inbox', icon: Inbox },
    { id: 'documents' as ViewType, label: 'Shared Files', icon: FileText },
  ];

  const enterpriseViews = [
    { id: 'dashboard' as ViewType, label: 'Executive View', icon: Home },
    { id: 'finance' as ViewType, label: 'Financial Reports', icon: Wallet },
    { id: 'agents' as ViewType, label: 'Agent Swarms', icon: Bot },
    { id: 'collaboration' as ViewType, label: 'Departments', icon: Building2 },
  ];

  const getViews = () => {
    switch (activeHub) {
      case 'personal':
        return personalViews;
      case 'group':
        return groupViews;
      case 'enterprise':
        return enterpriseViews;
      default:
        return personalViews;
    }
  };

  const getUserInitials = () => {
    if (user?.fullName) {
      return user.fullName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    }
    if (user?.email) {
      return user.email[0].toUpperCase();
    }
    return 'U';
  };

  return (
    <aside
      className={`fixed left-0 top-0 h-screen bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 z-40 ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Logo */}
      <div className="p-4 flex items-center justify-between border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          {!collapsed && (
            <div>
              <h1 className="font-bold text-lg text-sidebar-foreground">Atlas</h1>
              <p className="text-[10px] text-muted-foreground">Command Center</p>
            </div>
          )}
        </div>
        <button
          onClick={onToggleCollapse}
          className="w-8 h-8 rounded-lg bg-sidebar-accent hover:bg-sidebar-primary hover:text-sidebar-primary-foreground flex items-center justify-center transition-colors"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Hub Selector */}
      <div className="p-3">
        <div className={`flex ${collapsed ? 'flex-col gap-2' : 'gap-1'} p-1 bg-sidebar-accent rounded-xl`}>
          {hubs.map((hub) => {
            const Icon = hub.icon;
            const isActive = activeHub === hub.id;
            return (
              <button
                key={hub.id}
                onClick={() => onHubChange(hub.id)}
                className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg transition-all ${
                  isActive
                    ? `bg-gradient-to-r ${hub.color} text-white shadow-lg`
                    : 'hover:bg-sidebar-accent text-sidebar-foreground'
                }`}
                title={hub.label}
              >
                <Icon className="w-4 h-4" />
                {!collapsed && <span className="text-sm font-medium">{hub.label}</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Search */}
      {!collapsed && (
        <div className="px-3 pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search anything..."
              className="w-full bg-sidebar-accent rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sidebar-primary"
            />
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-3 py-2">
        {!collapsed && (
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2 px-3">
            {activeHub === 'personal' ? 'Personal Hub' : activeHub === 'group' ? 'Group Hub' : 'Enterprise Hub'}
          </p>
        )}
        <ul className="space-y-1">
          {getViews().map((view) => {
            const Icon = view.icon;
            const isActive = activeView === view.id;
            return (
              <li key={view.id}>
                <button
                  onClick={() => onViewChange(view.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${
                    isActive
                      ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                      : 'hover:bg-sidebar-accent text-sidebar-foreground'
                  }`}
                  title={view.label}
                >
                  <Icon className="w-5 h-5" />
                  {!collapsed && <span className="text-sm font-medium">{view.label}</span>}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Quick Actions */}
      <div className="p-3 border-t border-sidebar-border">
        <div className={`flex ${collapsed ? 'flex-col' : ''} gap-2`}>
          <button
            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-sidebar-accent hover:bg-sidebar-primary hover:text-sidebar-primary-foreground transition-colors"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {!collapsed && <span className="text-sm">Alerts</span>}
            <span className="w-5 h-5 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center">
              3
            </span>
          </button>
          <button
            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-sidebar-accent hover:bg-sidebar-primary hover:text-sidebar-primary-foreground transition-colors"
            title="Settings"
          >
            <Settings className="w-4 h-4" />
            {!collapsed && <span className="text-sm">Settings</span>}
          </button>
        </div>
      </div>

      {/* User Profile */}
      <div className="p-3 border-t border-sidebar-border">
        <div className={`flex items-center gap-3 ${collapsed ? 'justify-center' : ''}`}>
          {user?.avatarUrl ? (
            <img 
              src={user.avatarUrl} 
              alt={user.fullName || 'User'} 
              className="w-10 h-10 rounded-full object-cover"
            />
          ) : (
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white font-semibold">
              {isAuthenticated ? getUserInitials() : 'G'}
            </div>
          )}
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-sidebar-foreground truncate">
                {isAuthenticated ? (user?.fullName || 'User') : 'Guest'}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {isAuthenticated ? 'Premium Member' : 'Sign in to sync'}
              </p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};

export default MainSidebar;
