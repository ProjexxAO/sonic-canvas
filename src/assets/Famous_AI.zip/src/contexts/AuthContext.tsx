import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

interface User {
  id: string;
  email: string;
  fullName?: string;
  avatarUrl?: string;
}

interface UserPreferences {
  theme: string;
  defaultHub: string;
  notificationsEnabled: boolean;
  adhdMode: boolean;
  focusDuration: number;
  taxRegion: string;
}

interface AuthContextType {
  user: User | null;
  preferences: UserPreferences | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error?: string }>;
  signIn: (email: string, password: string) => Promise<{ error?: string }>;
  signInWithGoogle: () => Promise<{ error?: string }>;
  signInWithGithub: () => Promise<{ error?: string }>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ error?: string }>;
  updateProfile: (data: Partial<User>) => Promise<{ error?: string }>;
  updatePreferences: (data: Partial<UserPreferences>) => Promise<{ error?: string }>;
  refreshUser: () => Promise<void>;
}

const defaultPreferences: UserPreferences = {
  theme: 'dark',
  defaultHub: 'personal',
  notificationsEnabled: true,
  adhdMode: false,
  focusDuration: 25,
  taxRegion: 'US',
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [preferences, setPreferences] = useState<UserPreferences | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchUserProfile = useCallback(async (userId: string) => {
    try {
      const { data: profile, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching profile:', error);
        return null;
      }

      return profile;
    } catch (err) {
      console.error('Error fetching profile:', err);
      return null;
    }
  }, []);

  const fetchUserPreferences = useCallback(async (userId: string) => {
    try {
      const { data: prefs, error } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching preferences:', error);
        return null;
      }

      if (prefs) {
        return {
          theme: prefs.theme,
          defaultHub: prefs.default_hub,
          notificationsEnabled: prefs.notifications_enabled,
          adhdMode: prefs.adhd_mode,
          focusDuration: prefs.focus_duration,
          taxRegion: prefs.tax_region,
        };
      }

      return null;
    } catch (err) {
      console.error('Error fetching preferences:', err);
      return null;
    }
  }, []);

  const createUserProfile = async (userId: string, email: string, fullName?: string) => {
    try {
      // Create profile
      const { error: profileError } = await supabase
        .from('user_profiles')
        .insert({
          user_id: userId,
          email,
          full_name: fullName,
        });

      if (profileError) {
        console.error('Error creating profile:', profileError);
        return;
      }

      // Create default preferences
      const { error: prefsError } = await supabase
        .from('user_preferences')
        .insert({
          user_id: userId,
          ...defaultPreferences,
          default_hub: defaultPreferences.defaultHub,
          notifications_enabled: defaultPreferences.notificationsEnabled,
          adhd_mode: defaultPreferences.adhdMode,
          focus_duration: defaultPreferences.focusDuration,
          tax_region: defaultPreferences.taxRegion,
        });

      if (prefsError) {
        console.error('Error creating preferences:', prefsError);
      }
    } catch (err) {
      console.error('Error creating user profile:', err);
    }
  };

  const refreshUser = useCallback(async () => {
    // Check for stored session
    const storedUser = localStorage.getItem('atlas_user');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      setUser(userData);
      
      const prefs = await fetchUserPreferences(userData.id);
      setPreferences(prefs || defaultPreferences);
    }
    setIsLoading(false);
  }, [fetchUserPreferences]);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  const signUp = async (email: string, password: string, fullName: string): Promise<{ error?: string }> => {
    try {
      // Generate a unique user ID
      const userId = crypto.randomUUID();
      
      // Create user profile in database
      await createUserProfile(userId, email, fullName);
      
      // Store user data locally (simulating auth)
      const userData: User = {
        id: userId,
        email,
        fullName,
      };
      
      localStorage.setItem('atlas_user', JSON.stringify(userData));
      localStorage.setItem('atlas_password_hash', btoa(password)); // Simple encoding for demo
      
      setUser(userData);
      setPreferences(defaultPreferences);
      
      return {};
    } catch (err: any) {
      return { error: err.message || 'Failed to sign up' };
    }
  };

  const signIn = async (email: string, password: string): Promise<{ error?: string }> => {
    try {
      // Check if user exists in profiles
      const { data: profiles, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('email', email);

      if (error) {
        return { error: 'Failed to sign in' };
      }

      if (!profiles || profiles.length === 0) {
        return { error: 'Invalid email or password' };
      }

      const profile = profiles[0];
      
      // Store user data locally
      const userData: User = {
        id: profile.user_id,
        email: profile.email,
        fullName: profile.full_name,
        avatarUrl: profile.avatar_url,
      };
      
      localStorage.setItem('atlas_user', JSON.stringify(userData));
      
      setUser(userData);
      
      const prefs = await fetchUserPreferences(profile.user_id);
      setPreferences(prefs || defaultPreferences);
      
      return {};
    } catch (err: any) {
      return { error: err.message || 'Failed to sign in' };
    }
  };

  const signInWithGoogle = async (): Promise<{ error?: string }> => {
    try {
      // Simulate Google OAuth
      const userId = crypto.randomUUID();
      const email = `user${Date.now()}@gmail.com`;
      const fullName = 'Google User';
      
      await createUserProfile(userId, email, fullName);
      
      const userData: User = {
        id: userId,
        email,
        fullName,
        avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(fullName)}&background=4285f4&color=fff`,
      };
      
      localStorage.setItem('atlas_user', JSON.stringify(userData));
      setUser(userData);
      setPreferences(defaultPreferences);
      
      return {};
    } catch (err: any) {
      return { error: err.message || 'Failed to sign in with Google' };
    }
  };

  const signInWithGithub = async (): Promise<{ error?: string }> => {
    try {
      // Simulate GitHub OAuth
      const userId = crypto.randomUUID();
      const email = `user${Date.now()}@github.com`;
      const fullName = 'GitHub User';
      
      await createUserProfile(userId, email, fullName);
      
      const userData: User = {
        id: userId,
        email,
        fullName,
        avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(fullName)}&background=24292e&color=fff`,
      };
      
      localStorage.setItem('atlas_user', JSON.stringify(userData));
      setUser(userData);
      setPreferences(defaultPreferences);
      
      return {};
    } catch (err: any) {
      return { error: err.message || 'Failed to sign in with GitHub' };
    }
  };

  const signOut = async () => {
    localStorage.removeItem('atlas_user');
    localStorage.removeItem('atlas_password_hash');
    setUser(null);
    setPreferences(null);
  };

  const resetPassword = async (email: string): Promise<{ error?: string }> => {
    try {
      // Check if user exists
      const { data: profiles } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('email', email);

      if (!profiles || profiles.length === 0) {
        return { error: 'No account found with this email' };
      }

      // In a real app, this would send a password reset email
      // For demo purposes, we'll just return success
      return {};
    } catch (err: any) {
      return { error: err.message || 'Failed to send reset email' };
    }
  };

  const updateProfile = async (data: Partial<User>): Promise<{ error?: string }> => {
    if (!user) return { error: 'Not authenticated' };

    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({
          full_name: data.fullName,
          avatar_url: data.avatarUrl,
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', user.id);

      if (error) {
        return { error: error.message };
      }

      const updatedUser = { ...user, ...data };
      setUser(updatedUser);
      localStorage.setItem('atlas_user', JSON.stringify(updatedUser));
      
      return {};
    } catch (err: any) {
      return { error: err.message || 'Failed to update profile' };
    }
  };

  const updatePreferences = async (data: Partial<UserPreferences>): Promise<{ error?: string }> => {
    if (!user) return { error: 'Not authenticated' };

    try {
      const updateData: any = { updated_at: new Date().toISOString() };
      
      if (data.theme !== undefined) updateData.theme = data.theme;
      if (data.defaultHub !== undefined) updateData.default_hub = data.defaultHub;
      if (data.notificationsEnabled !== undefined) updateData.notifications_enabled = data.notificationsEnabled;
      if (data.adhdMode !== undefined) updateData.adhd_mode = data.adhdMode;
      if (data.focusDuration !== undefined) updateData.focus_duration = data.focusDuration;
      if (data.taxRegion !== undefined) updateData.tax_region = data.taxRegion;

      const { error } = await supabase
        .from('user_preferences')
        .update(updateData)
        .eq('user_id', user.id);

      if (error) {
        return { error: error.message };
      }

      setPreferences(prev => prev ? { ...prev, ...data } : null);
      
      return {};
    } catch (err: any) {
      return { error: err.message || 'Failed to update preferences' };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        preferences,
        isLoading,
        isAuthenticated: !!user,
        signUp,
        signIn,
        signInWithGoogle,
        signInWithGithub,
        signOut,
        resetPassword,
        updateProfile,
        updatePreferences,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
