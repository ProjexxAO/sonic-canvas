import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://qrnlwukdqhefzogtjpse.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjYxOGEwNmQxLTdjZGUtNDdkYi05ZDUzLWE1MGU2ZjNkZmRmZiJ9.eyJwcm9qZWN0SWQiOiJxcm5sd3VrZHFoZWZ6b2d0anBzZSIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzY5Mjc3NjY1LCJleHAiOjIwODQ2Mzc2NjUsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.CZ_JfxUbCVJzxZaOmZ-VW4fZNnjIs7EyVmsUwy2fTes';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };